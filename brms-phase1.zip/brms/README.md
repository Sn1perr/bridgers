# BRMS: Bridgers Resource Management System

Secure, role-based record keeping for Bridgers Resources Limited. This is **Phase 1** of the plan in the brief: authentication, roles and permissions, the dashboard, and central records management, with an append-only audit trail, private file attachments, backup and restore, and a tested set of core workflows.

## What works today

| Area | Included in Phase 1 |
|---|---|
| Sign-in | Email and password, bcrypt hashing, strong password policy, lockout after 5 failed attempts (15 minutes), forced password change on first login, idle timeout (30 min) and absolute timeout (12 h), server-side sessions that are revoked on logout, password change, role change and deactivation |
| Access control | Seven roles from the brief, 13 configurable permissions, permission matrix editable in Settings; navigation and pages hidden from users who lack access |
| Records | Auto reference numbers (`BR-REC-2026-0001`), title, description, custom categories, department, creator, dates, status (Active, Pending, Approved, Archived, Rejected), priority, notes, activity history, attachments |
| Workflow | Recording and approving are separate steps. The creator cannot approve their own record. Approved records are locked until an approver reopens them with a reason. Archive and restore keep full history. Delete is a soft delete with a mandatory reason |
| Search and filters | Global search bar; filters by category, department, status, creator and date range; sortable columns; pagination |
| Attachments | PDF, DOCX, XLSX, JPG, PNG up to 10 MB; type, size and file-signature checks; stored outside the web root under random names; downloads go through a permission check and are logged |
| Dashboard | Totals, status breakdown, 12-month creation trend, top categories, recent activity, items awaiting your approval. All computed from the database for the records the signed-in user may see |
| Audit | Sign-ins, failures, lockouts, creates, edits (with before and after), approvals, rejections, archives, deletions, uploads, downloads, user and permission changes. The table is protected by database triggers that block any UPDATE or DELETE |
| Operations | Backup and restore scripts with checksum verification |

## Not built yet (later phases)

Employees and HR, document repository with versions and expiry reminders, projects, clients and suppliers, correspondence and meetings, finance, procurement and inventory, report exports (PDF, Excel, CSV), email notifications, multi-factor authentication, self-service password reset by email. The navigation shows only modules that exist, so nothing appears as a dead link. See `docs/ROADMAP.md`.

## Requirements

* Node.js 22 or newer
* Linux, macOS or Windows server (Linux recommended)

## Setup

```bash
npm install
cp .env.example .env        # edit as needed
npm run db:seed             # creates departments, categories and the first Super Administrator
npm run build
npm run start               # http://localhost:3000
```

`db:seed` prints the administrator's one-time password unless you set `BRMS_ADMIN_PASSWORD`. You must change it at first sign-in. Seeding contains **no company data**: only structural defaults (six departments, eight categories) that you can change.

Next.js reads `.env` automatically for the web app. The scripts (`db:seed`, `backup`, `restore`) read real environment variables, so either export them in your shell first or run a script as, for example, `npx tsx --env-file=.env scripts/seed.ts`.

For development with live reload use `npm run dev`.

### Logo

Place the official logo at `public/logo.png` (or `logo.svg`). It replaces the gold placeholder box in the sidebar and sign-in screen automatically.

### Tests

```bash
npm test
```

Runs 82 checks against a throwaway database: sign-in, lockout, session timeout, record create, edit, duplicate prevention, visibility rules, approval separation of duties, locking and reopening, search and filters, archive, restore, soft delete, upload validation, downloads, categories, audit immutability and password changes, and user and permission administration.

## Deployment

1. **Host** a single Node process (a small VPS or any container host with a persistent disk). BRMS uses SQLite, which is reliable for one server and a small to medium team. Do not run several copies against the same database file.
2. **HTTPS is mandatory.** Put the app behind a reverse proxy that terminates TLS (Caddy or nginx) and forwards `X-Forwarded-For`. Session cookies are marked `Secure` in production, so sign-in will not work over plain HTTP.
3. **Run as a service** (systemd, Docker or PM2) with `NODE_ENV=production`, started with `npm run start`.
4. **Persistent storage:** set `BRMS_DATA_DIR` to a directory on persistent disk, outside the code folder, readable only by the service user (`chmod 700`). It holds `brms.db` and `uploads/`.
5. **Backups:** schedule `npm run backup -- /path/to/backups` daily (cron), and copy the backup folders off the server to encrypted storage. Test a restore at least quarterly.
6. **Firewall:** expose only ports 80 and 443.
7. **Updates:** `git pull`, `npm install`, `npm run build`, restart. Database migrations are applied automatically at start-up.

Example Caddyfile:

```
brms.example.com {
  encode gzip
  reverse_proxy localhost:3000
  request_body { max_size 12MB }
}
```

### Backup and recovery

```bash
npm run backup -- /var/backups/brms          # safe while the app is running
# disaster recovery: stop the app, then
npm run restore -- /var/backups/brms/brms-backup-<timestamp>
```

Restore verifies every file's checksum first, refuses a damaged backup without touching live data, and moves existing data aside instead of deleting it.

### Moving to PostgreSQL later

The schema is defined with Drizzle ORM (`src/db/schema.ts`). When the company needs several app servers or managed database hosting, the schema ports to PostgreSQL by switching the Drizzle dialect and driver and replacing the audit-table SQLite triggers with equivalent PostgreSQL triggers. This is planned for Phase 6.

## Documents

* `docs/ADMIN_GUIDE.md` administrator documentation
* `docs/USER_GUIDE.md` short guide for staff
* `docs/DATABASE_SCHEMA.md` tables and relationships
* `docs/ROADMAP.md` phases 2 to 6 and known limitations
