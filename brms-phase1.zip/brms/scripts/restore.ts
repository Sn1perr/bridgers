// Usage: npm run restore -- <backup-dir>
// STOP THE APP FIRST. Verifies every checksum, then replaces the live database and uploads with the backup.
// The current data is moved aside to <data-dir>.before-restore-<timestamp>, never deleted.
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

const dataDir = path.resolve(process.env.BRMS_DATA_DIR ?? "./data");
const backup = process.argv[2] ? path.resolve(process.argv[2]) : "";
if (!backup || !fs.existsSync(path.join(backup, "manifest.json"))) {
  console.error("Usage: npm run restore -- <path to a brms-backup-... folder>");
  process.exit(1);
}
const manifest = JSON.parse(fs.readFileSync(path.join(backup, "manifest.json"), "utf8")) as { files: Record<string, string> };
for (const [rel, expected] of Object.entries(manifest.files)) {
  const f = path.join(backup, rel);
  if (!fs.existsSync(f) || crypto.createHash("sha256").update(fs.readFileSync(f)).digest("hex") !== expected) {
    console.error(`Backup is damaged or incomplete: ${rel}. Nothing was changed.`);
    process.exit(1);
  }
}
if (fs.existsSync(dataDir)) {
  const aside = `${dataDir}.before-restore-${new Date().toISOString().replace(/[:.]/g, "-")}`;
  fs.renameSync(dataDir, aside);
  console.log(`Existing data moved to ${aside}`);
}
fs.mkdirSync(path.join(dataDir, "uploads"), { recursive: true });
fs.copyFileSync(path.join(backup, "brms.db"), path.join(dataDir, "brms.db"));
for (const f of fs.existsSync(path.join(backup, "uploads")) ? fs.readdirSync(path.join(backup, "uploads")) : [])
  fs.copyFileSync(path.join(backup, "uploads", f), path.join(dataDir, "uploads", f));
console.log(`Restored ${Object.keys(manifest.files).length} files from ${backup}. Start the app again.`);
