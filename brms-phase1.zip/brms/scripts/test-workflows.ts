// Runs the core workflows against a throwaway database. Usage: npm test
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "brms-test-"));
process.env.BRMS_DATA_DIR = tmp;
process.env.BRMS_ADMIN_EMAIL = "admin@test.local";
process.env.BRMS_ADMIN_PASSWORD = "Adm1n!Passw0rd#";

let passed = 0;
let failed = 0;
function check(name: string, cond: boolean, extra = "") {
  if (cond) { passed++; console.log(`  PASS  ${name}`); }
  else { failed++; console.log(`  FAIL  ${name} ${extra}`); }
}
function throws(name: string, fn: () => unknown, match?: RegExp) {
  try { fn(); check(name, false, "(did not throw)"); }
  catch (e) { check(name, !match || match.test((e as Error).message), `(got: ${(e as Error).message})`); }
}

async function main() {
  const { db, schema, rawDb } = await import("../src/db");
  const boot = await import("../src/lib/bootstrap");
  const auth = await import("../src/lib/auth-core");
  const svc = await import("../src/lib/records-service");
  const { eq } = await import("drizzle-orm");

  boot.seedDefaults();
  boot.seedAdmin();
  const mk = (email: string, role: string, dept: string) =>
    boot.createUser({ email, name: email.split("@")[0], role, password: "Str0ng!Passw0rd", departmentName: dept, mustChangePassword: false });
  mk("officer@test.local", "records_officer", "Administration");
  mk("md@test.local", "managing_director", "Administration");
  mk("acct@test.local", "accountant", "Finance & Accounts");
  mk("staff@test.local", "staff", "Operations");

  const sessionFor = (email: string, pw = "Str0ng!Passw0rd") => {
    const r = auth.loginWithPassword(email, pw, "127.0.0.1");
    if (!r.ok) throw new Error(`login failed for ${email}: ${r.error}`);
    return { token: r.token, user: auth.loadSession(r.token, "127.0.0.1")! };
  };

  console.log("\nAuthentication");
  check("good login succeeds", auth.loginWithPassword("officer@test.local", "Str0ng!Passw0rd").ok);
  const bad = auth.loginWithPassword("officer@test.local", "wrong");
  check("bad password rejected with generic message", !bad.ok && bad.error === "Invalid email or password.");
  const unknown = auth.loginWithPassword("nobody@test.local", "x");
  check("unknown email gives same message", !unknown.ok && unknown.error === "Invalid email or password.");
  for (let i = 0; i < 5; i++) auth.loginWithPassword("staff@test.local", "wrong");
  const locked = auth.loginWithPassword("staff@test.local", "Str0ng!Passw0rd");
  check("account locks after 5 failures (even with correct password)", !locked.ok && /locked/i.test(locked.error));
  db.update(schema.users).set({ lockedUntil: null }).where(eq(schema.users.email, "staff@test.local")).run();
  check("weak password rejected by policy", auth.passwordProblems("short").length > 0);
  const adminSess = sessionFor("admin@test.local", "Adm1n!Passw0rd#");
  check("admin must change password at first login", adminSess.user.mustChangePassword === true);

  console.log("\nSession timeout and logout");
  const s = sessionFor("officer@test.local");
  check("session valid", !!auth.loadSession(s.token));
  rawDb().prepare("UPDATE sessions SET last_seen_at = ?").run(new Date(Date.now() - 31 * 60_000).toISOString());
  check("idle session expires after 30 min", auth.loadSession(s.token) === null);
  const s2 = sessionFor("officer@test.local");
  auth.logout(s2.token, s2.user);
  check("logout invalidates session", auth.loadSession(s2.token) === null);

  const officer = sessionFor("officer@test.local").user;
  const md = sessionFor("md@test.local").user;
  const acct = sessionFor("acct@test.local").user;
  const staff = sessionFor("staff@test.local").user;
  const cats = svc.listCategories();
  const deps = svc.listDepartments();
  const adminDep = deps.find((d) => d.name === "Administration")!.id;
  const finDep = deps.find((d) => d.name === "Finance & Accounts")!.id;
  const opsDep = deps.find((d) => d.name === "Operations")!.id;

  console.log("\nRecords: create, validate, duplicates");
  const rec = svc.createRecord(officer, { title: "Office lease agreement", description: "Head office lease", categoryId: cats[0].id, departmentId: adminDep });
  check("auto reference number", /^BR-REC-\d{4}-0001$/.test(rec.refNo), rec.refNo);
  check("starts as Pending", rec.status === "Pending");
  const rec2 = svc.createRecord(officer, { title: "Second record", categoryId: cats[0].id, departmentId: adminDep });
  check("reference numbers increment", rec2.refNo.endsWith("0002"));
  throws("missing title rejected", () => svc.createRecord(officer, { title: " ", categoryId: cats[0].id, departmentId: adminDep }), /title/i);
  throws("duplicate title+category rejected", () => svc.createRecord(officer, { title: "OFFICE LEASE AGREEMENT", categoryId: cats[0].id, departmentId: adminDep }), /already exists/);
  check("duplicate allowed when confirmed", !!svc.createRecord(officer, { title: "Office lease agreement", categoryId: cats[0].id, departmentId: adminDep }, { allowDuplicate: true }));
  throws("cannot create directly as Approved", () => svc.createRecord(officer, { title: "Sneaky", categoryId: cats[0].id, departmentId: adminDep, status: "Approved" }), /approval/i);

  console.log("\nPermissions and visibility");
  const accRec = svc.createRecord(acct, { title: "Q3 supplier statement", categoryId: cats[0].id, departmentId: finDep });
  throws("staff cannot create for another department", () => svc.createRecord(staff, { title: "Cross dept", categoryId: cats[0].id, departmentId: finDep }), /own department/);
  check("staff does not see other departments' records", svc.listRecords(staff).rows.length === 0);
  throws("staff cannot open another department's record", () => svc.getRecordDetail(staff, accRec.id), /not found/i);
  check("accountant sees own department only", svc.listRecords(acct).rows.every((r) => r.department === "Finance & Accounts"));
  check("officer (view_all) sees all", svc.listRecords(officer).total >= 4);
  throws("staff cannot approve", () => svc.decide(staff, rec.id, "Approved"), /permission/);
  throws("staff cannot manage categories", () => svc.createCategory(staff, "Hack"), /permission/);

  console.log("\nApproval workflow");
  const own = svc.createRecord(adminSess.user, { title: "Admin's own record", categoryId: cats[0].id, departmentId: adminDep });
  throws("creator cannot approve own record (separation of duties)", () => svc.decide(adminSess.user, own.id, "Approved"), /cannot approve/i);
  svc.decide(md, rec.id, "Approved");
  check("MD can approve others' record", svc.getRecordDetail(md, rec.id).r.status === "Approved");
  throws("approved record is locked against edits", () => svc.updateRecord(officer, rec.id, { title: "Changed", categoryId: cats[0].id, departmentId: adminDep }), /locked/i);
  throws("rejection requires a reason", () => svc.decide(md, rec2.id, "Rejected", ""), /reason/i);
  svc.decide(md, rec2.id, "Rejected", "Missing signature page");
  check("rejection recorded with note", svc.getRecordDetail(md, rec2.id).notes.some((n) => /Missing signature/.test(n.body)));
  throws("officer cannot reopen (no approve permission)", () => svc.reopen(officer, rec.id, "typo"), /permission/);
  svc.reopen(md, rec.id, "Correct the lease term");
  check("reopen returns to Pending", svc.getRecordDetail(md, rec.id).r.status === "Pending");
  svc.updateRecord(officer, rec.id, { title: "Office lease agreement (2026)", description: "Head office lease", categoryId: cats[0].id, departmentId: adminDep });
  check("edit works after reopen", svc.getRecordDetail(officer, rec.id).r.title.includes("2026"));
  const detail = svc.getRecordDetail(officer, rec.id);
  const upd = detail.history.find((h) => h.action === "record.updated");
  check("edit diff stored in history", !!upd && /title/.test(upd.detail ?? ""));

  console.log("\nSearch, filter, sort, paginate");
  for (let i = 0; i < 20; i++) svc.createRecord(officer, { title: `Bulk filing ${i}`, categoryId: cats[1].id, departmentId: adminDep });
  const page1 = svc.listRecords(officer, { pageSize: 10 });
  check("pagination", page1.rows.length === 10 && page1.pages >= 3);
  check("search by title", svc.listRecords(officer, { q: "lease" }).rows.every((r) => /lease/i.test(r.title)));
  check("search by reference", svc.listRecords(officer, { q: rec.refNo }).total === 1);
  check("search treats % literally", svc.listRecords(officer, { q: "%" }).total === 0);
  check("filter by category", svc.listRecords(officer, { categoryId: cats[1].id }).total === 20);
  check("filter by status", svc.listRecords(officer, { status: "Rejected" }).total === 1);
  check("sort ascending by title", (() => { const r = svc.listRecords(officer, { sort: "title", dir: "asc", pageSize: 100 }).rows; return r.every((x, i) => i === 0 || r[i - 1].title <= x.title); })());

  console.log("\nArchive, restore, soft delete");
  throws("staff cannot archive", () => svc.archiveRecord(staff, rec.id), /permission/);
  svc.archiveRecord(officer, rec.id);
  check("archived hidden from default list", svc.listRecords(officer, { q: rec.refNo }).total === 0);
  check("archived visible with status filter", svc.listRecords(officer, { status: "Archived", q: rec.refNo }).total === 1);
  svc.restoreRecord(officer, rec.id);
  check("restore returns previous status", svc.getRecordDetail(officer, rec.id).r.status === "Pending");
  const del = svc.createRecord(officer, { title: "To be deleted", categoryId: cats[0].id, departmentId: adminDep });
  svc.deleteRecord(officer, del.id, "Entered in error");
  throws("deleted record no longer reachable", () => svc.getRecordDetail(officer, del.id), /not found/i);
  check("deleted row kept in database (soft delete)", !!db.select().from(schema.records).where(eq(schema.records.id, del.id)).get()?.deletedAt);

  console.log("\nAttachments");
  const pdf = Buffer.concat([Buffer.from("%PDF-1.4\n"), Buffer.alloc(100, 1)]);
  const att = svc.addAttachment(officer, rec.id, "../../lease agreement.pdf", pdf);
  check("valid PDF accepted, name sanitised", att.originalName === "lease agreement.pdf");
  check("stored under random name", !att.storedName.includes("lease"));
  throws("exe rejected", () => svc.addAttachment(officer, rec.id, "x.exe", pdf), /Only PDF/);
  throws("wrong magic bytes rejected", () => svc.addAttachment(officer, rec.id, "fake.pdf", Buffer.from("MZ not a pdf")), /do not match/);
  throws("oversize rejected", () => svc.addAttachment(officer, rec.id, "big.pdf", Buffer.concat([Buffer.from("%PDF"), Buffer.alloc(11 * 1024 * 1024)])), /too large/);
  const dl = svc.openAttachment(officer, att.id);
  check("download returns identical bytes", dl.data.equals(pdf));
  throws("staff in another dept cannot download", () => svc.openAttachment(staff, att.id), /not found|permission/i);

  console.log("\nCategories");
  const newCat = svc.createCategory(officer, "Insurance");
  check("custom category created", newCat.name === "Insurance");
  throws("duplicate category rejected", () => svc.createCategory(officer, "insurance"), /already exists/);

  console.log("\nAudit trail");
  const n = rawDb().prepare("SELECT count(*) c FROM audit_logs").get() as { c: number };
  check("events logged", n.c > 30, String(n.c));
  throws("audit rows cannot be updated", () => rawDb().prepare("UPDATE audit_logs SET action='x' WHERE id=1").run(), /append-only/);
  throws("audit rows cannot be deleted", () => rawDb().prepare("DELETE FROM audit_logs").run(), /append-only/);
  const actions = (rawDb().prepare("SELECT DISTINCT action FROM audit_logs").all() as { action: string }[]).map((a) => a.action);
  for (const a of ["login.success", "login.failed", "login.locked", "record.created", "record.approved", "record.rejected", "record.updated", "record.archived", "record.deleted", "attachment.uploaded", "attachment.downloaded"])
    check(`audited: ${a}`, actions.includes(a));

  console.log("\nPassword change");
  const bad2 = auth.changePassword(officer.id, "wrong", "NewStr0ng!Pass", officer);
  check("wrong current password rejected", !bad2.ok);
  const ok2 = auth.changePassword(officer.id, "Str0ng!Passw0rd", "NewStr0ng!Pass", officer);
  check("password change succeeds and revokes sessions", ok2.ok && auth.loadSession(s.token) === null);
  check("new password works", auth.loginWithPassword("officer@test.local", "NewStr0ng!Pass").ok);

  console.log("\nUser and permission administration");
  const admin = auth.loadSession(sessionFor("admin@test.local", "Adm1n!Passw0rd#").token)!;
  const adm = await import("../src/lib/admin-service");
  const nu = adm.adminCreateUser(admin, { name: "New Person", email: "new@test.local", role: "staff", departmentId: opsDep, password: "Temp0rary!Pass1" });
  check("admin creates user who must change password", nu.mustChangePassword === true);
  throws("duplicate email rejected", () => adm.adminCreateUser(admin, { name: "Dup", email: "NEW@test.local", role: "staff", departmentId: opsDep, password: "Temp0rary!Pass1" }), /already exists/);
  throws("weak temporary password rejected", () => adm.adminCreateUser(admin, { name: "Weak", email: "weak@test.local", role: "staff", departmentId: opsDep, password: "abc" }), /needs/);
  throws("non-admin cannot create users", () => adm.adminCreateUser(officer, { name: "X", email: "x@test.local", role: "staff", departmentId: opsDep, password: "Temp0rary!Pass1" }), /permission/);
  throws("last Super Administrator cannot be demoted", () => adm.adminUpdateUser(admin, admin.id, { role: "staff", departmentId: adminDep }), /at least one/);
  throws("cannot deactivate yourself", () => adm.adminSetActive(admin, admin.id, false), /own account/);
  const victim = sessionFor("new@test.local", "Temp0rary!Pass1");
  adm.adminSetActive(admin, nu.id, false);
  check("deactivation ends live sessions", auth.loadSession(victim.token) === null);
  check("deactivated user cannot sign in", !auth.loginWithPassword("new@test.local", "Temp0rary!Pass1").ok);
  const before = svc.listRecords(auth.loadSession(sessionFor("acct@test.local").token)!).total;
  adm.setRolePermissions(admin, "accountant", [...(adm.getRoleMatrix().get("accountant") ?? []), "records.view_all"]);
  const after = svc.listRecords(auth.loadSession(sessionFor("acct@test.local").token)!).total;
  check("granting records.view_all widens what a role sees", after > before, `${before} -> ${after}`);
  throws("Super Administrator permissions cannot be edited", () => adm.setRolePermissions(admin, "super_admin", []), /always/);
  check("permission change is audited", (rawDb().prepare("SELECT count(*) c FROM audit_logs WHERE action='role.permissions_changed'").get() as { c: number }).c === 1);

  console.log(`\n${passed} passed, ${failed} failed`);
  fs.rmSync(tmp, { recursive: true, force: true });
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error(e); process.exit(1); });
