// Usage: npm run backup [-- <target-dir>]
// Creates <target>/brms-backup-<timestamp>/ containing a consistent database snapshot, the uploaded files, and a checksum manifest.
import Database from "better-sqlite3";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

const dataDir = path.resolve(process.env.BRMS_DATA_DIR ?? "./data");
const target = path.resolve(process.argv[2] ?? "./backups");
const stamp = new Date().toISOString().replace(/[:.]/g, "-");
const out = path.join(target, `brms-backup-${stamp}`);
fs.mkdirSync(path.join(out, "uploads"), { recursive: true });

const sha = (f: string) => crypto.createHash("sha256").update(fs.readFileSync(f)).digest("hex");

async function main() {
  const src = new Database(path.join(dataDir, "brms.db"), { readonly: true });
  await src.backup(path.join(out, "brms.db")); // safe while the app is running
  src.close();
  const manifest: Record<string, string> = { "brms.db": sha(path.join(out, "brms.db")) };
  const upDir = path.join(dataDir, "uploads");
  for (const f of fs.existsSync(upDir) ? fs.readdirSync(upDir) : []) {
    fs.copyFileSync(path.join(upDir, f), path.join(out, "uploads", f));
    fs.chmodSync(path.join(out, "uploads", f), 0o600);
    manifest[`uploads/${f}`] = sha(path.join(upDir, f));
  }
  fs.writeFileSync(path.join(out, "manifest.json"), JSON.stringify({ createdAt: new Date().toISOString(), files: manifest }, null, 2));
  console.log(`Backup written to ${out}\n  ${Object.keys(manifest).length} files. Store a copy off-site and encrypted.`);
}
main().catch((e) => { console.error(e); process.exit(1); });
