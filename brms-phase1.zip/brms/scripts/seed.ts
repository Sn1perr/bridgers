import { seedAdmin, seedDefaults } from "../src/lib/bootstrap";

seedDefaults();
const admin = seedAdmin();
if (admin) {
  console.log("\nSuper Administrator created.");
  console.log(`  Email:    ${admin.email}`);
  if (admin.generated) console.log(`  Password: ${admin.password}   (shown once; you must change it at first login)`);
  else console.log("  Password: the value of BRMS_ADMIN_PASSWORD (you must change it at first login)");
} else {
  console.log("Administrator already exists; nothing to create.");
}
console.log("Default departments and record categories are in place.");
