# User Guide

## Signing in

Open the BRMS address, enter your work email and password. On your first sign-in you will be asked to choose a new password. Use at least 10 characters with capital and small letters, a number and a symbol. If you forget your password, ask your administrator to reset it.

For safety you are signed out after 30 minutes without activity. Always use **Sign out** on a shared computer.

## Finding your way around

* **Left menu:** Dashboard, Records, Notifications and (for administrators) Settings. Press the arrows at the top of the menu to make it narrower. On a phone, open it with the menu button.
* **Search box (top):** type a title, reference number or words from the description and press Enter.
* **Bell:** shows when something needs your attention, such as one of your records being approved or rejected.

## Creating a record

1. Choose **New record**.
2. Fill in the title, category and department. Add a description if useful.
3. Choose **Pending** if someone must approve it, or **Active** if not.
4. Choose **Create record**. The system gives it a reference number such as `BR-REC-2026-0042`.

If a record with the same title already exists in that category you will be warned. Open the existing one first; tick "create anyway" only if it really is a different record.

## Adding files and notes

On the record page, choose a file under **Attachments** and press **Upload**. PDF, Word, Excel, JPG and PNG files up to 10 MB are accepted. Use **Internal notes** for comments that colleagues should see.

## Finding records

Open **Records**. Use the filters (category, status, department, who created it, dates) and press **Apply filters**. Click a column heading to sort. Archived records are hidden unless you choose Archived in the Status filter.

## Editing, approving and archiving

* **Edit** is available while a record is Active, Pending or Rejected. Approved and archived records are locked.
* **Approve** and **Reject** appear only if you are an approver and did not create the record. Rejection needs a reason.
* An approver can **Reopen** an approved record if it must be corrected.
* **Archive** keeps the record but removes it from everyday lists. **Restore** brings it back.
* **Delete** hides a record and requires a reason. The history is kept for audit.

Every change is listed under **Activity history** on the record, with who did it and when.

## Good habits

* Use clear titles that someone else could search for.
* Attach the supporting document to the record instead of emailing it around.
* Never share your password. Everything you do is recorded under your name.
