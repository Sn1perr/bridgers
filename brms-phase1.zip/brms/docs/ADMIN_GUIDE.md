# Administrator Guide

## First day

1. Run `npm run db:seed` and note the one-time password for the Super Administrator account.
2. Sign in and set a new password (10+ characters, upper and lower case, a number and a symbol).
3. Go to **Settings > Users** and create an account for each person. Choose their role and department and give a temporary password. They must change it at first sign-in.
4. Go to **Settings > Record categories** and add or disable categories to match how the company files its records.
5. Review **Settings > Roles and permissions** (see below) and adjust to company policy.
6. Create a second Super Administrator so the company is never locked out. The system refuses to deactivate or demote the last one.

## Roles and what they can do by default

| Role | Default permissions |
|---|---|
| Super Administrator | Everything. Cannot be reduced |
| Managing Director | Dashboard, view all records, approve or reject, download files, view audit log |
| Records Officer | Dashboard, view all records, create, edit, archive and restore, upload and download, manage categories |
| Accountant, HR Officer, Project Manager, Departmental Staff | Dashboard, create and edit records, upload and download. See only records of their own department or that they created |

"View all records" (`records.view_all`) is what separates company-wide visibility from department-only visibility. Without it a user sees only their department's records and their own.

Staff who lack `records.view_all` can edit only records they created. Approval always needs `records.approve` and a different person from the creator.

Changes to permissions take effect on the user's next page load and are written to the audit log, showing exactly what was added or removed.

## Managing users

* **Role or department change** signs the user out so the new rights apply cleanly.
* **Deactivate** signs the user out immediately and blocks sign-in. Their records and history remain. People are never deleted, so the audit trail stays complete.
* **Reset password** sets a temporary password you give to the person; they must change it at next sign-in and all their sessions are ended. Never email passwords in plain text; give them in person or by phone.
* After 5 wrong passwords an account locks for 15 minutes. This is logged as `login.locked`.

## Approvals and corrections

* New records start as Pending (or Active if no approval is needed).
* An approver other than the creator approves or rejects. A rejection requires a reason, which becomes a note on the record and a notification to the creator.
* Approved records are locked. To correct one, an approver uses **Reopen** (with a reason); it returns to Pending, is edited, and is approved again. Every step is in the record's activity history.
* **Archive** hides a record from normal lists but keeps everything. **Restore** returns it to its previous status.
* **Delete** removes a record from every list but keeps the row, its files and its history. A reason is required, and approved records cannot be deleted (archive them).

## Audit log

**Settings > Audit log** is visible to anyone with `audit.view` (Super Administrator and Managing Director by default). It is append-only: database triggers reject any update or deletion of its rows, so even an administrator cannot alter history through the application. Filter by user email or event type.

Logged events include: `login.success`, `login.failed`, `login.locked`, `logout`, `password.changed`, `password.reset`, `user.created`, `user.updated`, `user.deactivated`, `role.permissions_changed`, `record.created`, `record.updated`, `record.approved`, `record.rejected`, `record.reopened`, `record.archived`, `record.restored`, `record.deleted`, `record.note_added`, `attachment.uploaded`, `attachment.downloaded`, `attachment.removed`, `category.created`.

## Backups

Daily cron example (runs at 02:00 and keeps files on the server; also copy them off-site):

```
0 2 * * * cd /opt/brms && BRMS_DATA_DIR=/var/lib/brms npm run -s backup -- /var/backups/brms
```

Test recovery every quarter on a spare machine with `npm run restore`. A backup you have never restored is not yet a backup.

## Data protection (Nigeria Data Protection Act 2023)

BRMS is built to support compliance; legal compliance also depends on how the company uses it. Points to settle with your legal adviser or Data Protection Officer:

* **Lawful basis and purpose:** record why each category of personal data is held (for example employee files, supplier contacts).
* **Access control and confidentiality:** use roles so people see only what their job needs; review the permission matrix and the user list at least quarterly and deactivate leavers the same day.
* **Security:** keep HTTPS on, the server patched, the data directory private and backups encrypted.
* **Accountability:** the audit log shows who accessed or changed records.
* **Retention and erasure:** decide retention periods. BRMS archives and soft-deletes by design; permanent erasure of personal data on a lawful request needs a controlled administrator procedure, which is on the roadmap.
* **Breach response:** the audit log and backups support investigation; the company needs its own breach notification procedure.
* **Cross-border transfers:** if you host outside Nigeria, confirm the transfer basis.

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| Cannot sign in over `http://` in production | Cookies are `Secure`; use HTTPS |
| "File is missing from storage" | The uploads folder was not restored with the database. Restore from a full backup |
| User cannot see a record a colleague can | The user lacks `records.view_all` and the record belongs to another department |
| Locked out of every admin account | Run `npm run db:seed` with a new `BRMS_ADMIN_EMAIL` to create a fresh Super Administrator |
