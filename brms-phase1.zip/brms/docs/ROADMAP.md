# Roadmap and Known Limitations

## Status against the implementation plan

| Phase | Scope | Status |
|---|---|---|
| 1 | Authentication, roles, dashboard, central records | **Done and tested** |
| 2 | Employee management, document storage, search | Next |
| 3 | Projects, clients, suppliers, correspondence | Planned |
| 4 | Finance, approvals, reporting | Planned |
| 5 | Procurement, inventory, notifications, analytics | Planned |
| 6 | Security testing, PostgreSQL option, UAT, deployment | Planned |

## Recommended order of work inside later phases

* **Phase 2:** employees (with a restricted HR permission set and confidential fields), document repository reusing the attachment engine plus versions and expiry dates, search across modules.
* **Phase 4:** finance must keep recording, approval and reconciliation as separate steps, corrections as reversing entries (never edits), amounts stored as integer kobo, and no bank connection.
* **Reports:** PDF, Excel and CSV generation arrives with Phase 4 because financial reports are the main consumer.

## Known limitations of Phase 1 (be aware before go-live)

1. **No multi-factor authentication yet.** Strongly recommended before holding financial or HR data. Planned for Phase 6 at the latest.
2. **No self-service password reset by email.** Administrators issue temporary passwords. Email delivery is not configured.
3. **No email notifications.** In-app notifications only (approval and rejection events). Deadline, expiry and low-stock alerts need the modules that generate them.
4. **Single-server SQLite.** Appropriate for one server and a small to medium team. PostgreSQL port is planned.
5. **Upload scanning:** files are validated by extension, size and file signature but not scanned for malware. Consider adding antivirus scanning on the server.
6. **No in-app document preview** yet; files download.
7. **Rate limiting** is per account (lockout). Add a proxy-level request limit (for example in Caddy or nginx) for per-IP protection.
8. **Secure erasure** of personal data (NDPA data subject requests) is not yet implemented; soft delete preserves data by design.
9. **Dashboard** shows record metrics only, because employees, projects, finance and the other modules are not built yet. Their cards appear when those modules exist.
10. Dependency audit shows moderate advisories in development tooling; run `npm audit` before each release.
