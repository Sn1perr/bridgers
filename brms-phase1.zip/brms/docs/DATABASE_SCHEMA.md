# Database Schema (Phase 1)

Source of truth: `src/db/schema.ts`. Migrations are in `drizzle/` and run automatically at start-up. Engine: SQLite (WAL mode, foreign keys on). Timestamps are ISO 8601 UTC text.

```
departments 1───* users 1───* sessions
     │              │
     │              ├──* records (created_by, updated_by, approved_by)
     │              ├──* record_notes (author_id)
     │              ├──* attachments (uploaded_by)
     │              └──* notifications
     └──* records *───1 categories
              ├──* record_notes
              └──* attachments

role_permissions (role, permission)   audit_logs (append-only)   counters (key, value)
```

| Table | Purpose | Key columns |
|---|---|---|
| `departments` | Organisational units | `name` unique |
| `users` | Accounts | `email` unique, `password_hash` (bcrypt, cost 12), `role`, `department_id`, `active`, `must_change_password`, `failed_attempts`, `locked_until`, `last_login_at` |
| `sessions` | Server-side sessions | `id` = SHA-256 of the cookie token (raw token never stored), `user_id`, `created_at`, `last_seen_at`, `ip` |
| `role_permissions` | Configurable permission matrix | primary key (`role`, `permission`) |
| `categories` | Custom record categories | `name` unique, `active` |
| `counters` | Per-year reference sequence | `key` like `record-2026`, `value` |
| `records` | Central records | `ref_no` unique (`BR-REC-YYYY-NNNN`), `title`, `description`, `category_id`, `department_id`, `created_by`, `updated_by`, `status`, `priority`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `deleted_at` (soft delete), `is_demo` |
| `record_notes` | Internal notes | `record_id`, `author_id`, `body` |
| `attachments` | File metadata | `record_id`, `original_name`, `stored_name` (random UUID), `mime_type`, `size`, `sha256`, `uploaded_by`, `deleted_at` |
| `audit_logs` | Permanent history | `at`, `user_id`, `user_email`, `action`, `entity`, `entity_id`, `detail` (JSON), `ip`. Triggers `audit_logs_no_update` and `audit_logs_no_delete` abort any change |
| `notifications` | In-app alerts | `user_id`, `title`, `body`, `href`, `read_at` |

Indexes: records by status, category, department and created date; audit by entity and time.

Statuses: Active, Pending, Approved, Archived, Rejected. Priorities: Low, Normal, High, Urgent.

Files live on disk in `<data dir>/uploads/<stored_name>`, never in a web-served folder.

Planned tables for later phases: employees, leave, documents and versions, projects, milestones, tasks, clients and suppliers, correspondence, meetings, financial transactions and approvals, purchase requests, orders, stock and assets.
