import Link from "next/link";
import { PageHeader } from "@/components/ui";
import { ROLES } from "@/lib/permissions";
import { requireUser } from "@/lib/session";

export const metadata = { title: "My account" };

export default async function Account() {
  const user = await requireUser();
  return (
    <>
      <PageHeader title="My account" />
      <div className="card max-w-xl">
        <dl className="space-y-2 text-sm">
          <div className="flex justify-between"><dt className="text-slate-500">Name</dt><dd className="font-medium">{user.name}</dd></div>
          <div className="flex justify-between"><dt className="text-slate-500">Email</dt><dd className="font-medium">{user.email}</dd></div>
          <div className="flex justify-between"><dt className="text-slate-500">Role</dt><dd className="font-medium">{ROLES[user.role]}</dd></div>
        </dl>
        <Link href="/change-password" className="btn-primary mt-5">Change password</Link>
      </div>
    </>
  );
}
