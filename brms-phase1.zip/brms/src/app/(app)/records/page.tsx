import Link from "next/link";
import { Empty, PageHeader, Priority, StatusBadge, fmtDate } from "@/components/ui";
import { RECORD_STATUSES } from "@/lib/permissions";
import { listCategories, listDepartments, listPeople, listRecords } from "@/lib/records-service";
import { requirePermission } from "@/lib/session";

export const metadata = { title: "Records" };
export const dynamic = "force-dynamic";

type SP = Record<string, string | undefined>;

function href(sp: SP, patch: SP) {
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries({ ...sp, ...patch })) if (v) q.set(k, v);
  const s = q.toString();
  return `/records${s ? `?${s}` : ""}`;
}

export default async function RecordsPage({ searchParams }: { searchParams: Promise<SP> }) {
  const user = await requirePermission("records.view");
  const sp = await searchParams;
  const num = (v?: string) => (v && /^\d+$/.test(v) ? Number(v) : undefined);
  const res = listRecords(user, {
    q: sp.q, categoryId: num(sp.cat), departmentId: num(sp.dep), createdBy: num(sp.by), status: sp.status,
    from: sp.from, to: sp.to, sort: sp.sort, dir: sp.dir === "asc" ? "asc" : "desc", page: num(sp.page),
  });
  const cats = listCategories(false);
  const deps = listDepartments();
  const people = listPeople();
  const filtered = !!(sp.q || sp.cat || sp.dep || sp.by || sp.status || sp.from || sp.to);

  const sortLink = (key: string, label: string) => {
    const active = (sp.sort ?? "updatedAt") === key;
    const nextDir = active && sp.dir !== "asc" ? "asc" : "desc";
    return (
      <Link href={href(sp, { sort: key, dir: nextDir, page: undefined })} className="inline-flex items-center gap-1 hover:text-navy-900">
        {label}{active ? (sp.dir === "asc" ? " ▲" : " ▼") : ""}
      </Link>
    );
  };

  return (
    <>
      <PageHeader
        title="Records"
        subtitle={`${res.total} record${res.total === 1 ? "" : "s"}${filtered ? " match your filters" : ""}. Archived records are hidden unless you filter by Archived.`}
        actions={user.permissions.has("records.create") ? <Link href="/records/new" className="btn-gold">New record</Link> : undefined}
      />
      {sp.deleted && <div role="status" className="mb-4 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-800">Record deleted. It is retained in the audit trail.</div>}

      <form method="get" className="card mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4" aria-label="Filter records">
        <div className="sm:col-span-2">
          <label htmlFor="q" className="label">Search</label>
          <input id="q" name="q" defaultValue={sp.q} placeholder="Title, reference number or description" className="input" />
        </div>
        <div>
          <label htmlFor="cat" className="label">Category</label>
          <select id="cat" name="cat" defaultValue={sp.cat ?? ""} className="input">
            <option value="">All</option>
            {cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="status" className="label">Status</label>
          <select id="status" name="status" defaultValue={sp.status ?? ""} className="input">
            <option value="">All except archived</option>
            {RECORD_STATUSES.map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>
        {user.permissions.has("records.view_all") && (
          <div>
            <label htmlFor="dep" className="label">Department</label>
            <select id="dep" name="dep" defaultValue={sp.dep ?? ""} className="input">
              <option value="">All</option>
              {deps.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
        )}
        <div>
          <label htmlFor="by" className="label">Created by</label>
          <select id="by" name="by" defaultValue={sp.by ?? ""} className="input">
            <option value="">Anyone</option>
            {people.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="from" className="label">Created from</label>
          <input id="from" name="from" type="date" defaultValue={sp.from} className="input" />
        </div>
        <div>
          <label htmlFor="to" className="label">Created to</label>
          <input id="to" name="to" type="date" defaultValue={sp.to} className="input" />
        </div>
        <div className="flex items-end gap-2 sm:col-span-2 lg:col-span-4">
          <button className="btn-primary">Apply filters</button>
          {filtered && <Link href="/records" className="btn-ghost">Clear</Link>}
        </div>
      </form>

      {res.rows.length === 0 ? (
        filtered ? (
          <Empty title="No records match" hint="Try removing a filter or searching for different words." action={<Link href="/records" className="btn-ghost">Clear filters</Link>} />
        ) : (
          <Empty title="No records yet" hint="Records you are allowed to see will be listed here." action={user.permissions.has("records.create") ? <Link href="/records/new" className="btn-gold">Create the first record</Link> : undefined} />
        )
      ) : (
        <div className="card overflow-hidden p-0">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px]">
              <thead className="border-b border-slate-200 bg-slate-50">
                <tr>
                  <th className="th" scope="col">{sortLink("refNo", "Reference")}</th>
                  <th className="th" scope="col">{sortLink("title", "Title")}</th>
                  <th className="th" scope="col">Category</th>
                  <th className="th" scope="col">Department</th>
                  <th className="th" scope="col">{sortLink("status", "Status")}</th>
                  <th className="th" scope="col">{sortLink("priority", "Priority")}</th>
                  <th className="th" scope="col">{sortLink("updatedAt", "Updated")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {res.rows.map((r) => (
                  <tr key={r.id} className="hover:bg-navy-50">
                    <td className="td whitespace-nowrap font-mono text-xs">{r.refNo}</td>
                    <td className="td font-medium">
                      <Link href={`/records/${r.id}`} className="text-navy-800 hover:underline">{r.title}</Link>
                      {r.isDemo && <span className="ml-2 rounded bg-gold-100 px-1.5 py-0.5 text-[10px] font-bold uppercase text-gold-500">Demo</span>}
                      <div className="text-xs font-normal text-slate-500">by {r.creator}</div>
                    </td>
                    <td className="td">{r.category}</td>
                    <td className="td">{r.department}</td>
                    <td className="td"><StatusBadge status={r.status} /></td>
                    <td className="td"><Priority value={r.priority} /></td>
                    <td className="td whitespace-nowrap text-slate-600">{fmtDate(r.updatedAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex items-center justify-between border-t border-slate-200 px-4 py-3 text-sm">
            <span className="text-slate-600">Page {res.page} of {res.pages}</span>
            <div className="flex gap-2">
              {res.page > 1 && <Link className="btn-ghost" href={href(sp, { page: String(res.page - 1) })}>Previous</Link>}
              {res.page < res.pages && <Link className="btn-ghost" href={href(sp, { page: String(res.page + 1) })}>Next</Link>}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
