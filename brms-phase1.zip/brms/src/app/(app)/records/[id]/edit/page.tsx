import { notFound, redirect } from "next/navigation";
import { PageHeader } from "@/components/ui";
import { ServiceError, getRecordDetail, listCategories, listDepartments } from "@/lib/records-service";
import { requirePermission } from "@/lib/session";
import { updateRecordAction } from "../../actions";
import { RecordForm } from "../../record-form";

export const metadata = { title: "Edit record" };

export default async function EditRecord({ params }: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("records.edit");
  const id = Number((await params).id);
  if (!Number.isInteger(id)) notFound();
  let d;
  try { d = getRecordDetail(user, id); } catch (e) { if (e instanceof ServiceError) notFound(); throw e; }
  if (!d.can.edit) redirect(`/records/${id}`);
  const viewAll = user.permissions.has("records.view_all");
  const cats = listCategories(false).filter((c) => c.active || c.id === d.r.categoryId);
  const deps = listDepartments();
  return (
    <>
      <PageHeader title={`Edit ${d.r.refNo}`} subtitle="Changes are recorded in the history with the before and after values." />
      <RecordForm
        action={updateRecordAction.bind(null, id)}
        categories={cats}
        departments={viewAll || !user.departmentId ? deps : deps.filter((x) => x.id === user.departmentId || x.id === d.r.departmentId)}
        defaults={{ title: d.r.title, description: d.r.description, categoryId: d.r.categoryId, departmentId: d.r.departmentId, priority: d.r.priority, status: d.r.status }}
        cancelHref={`/records/${id}`}
        isNew={false}
      />
    </>
  );
}
