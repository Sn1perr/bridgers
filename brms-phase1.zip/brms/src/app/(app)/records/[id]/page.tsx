import Link from "next/link";
import { notFound } from "next/navigation";
import { Download, Paperclip } from "lucide-react";
import { ActionForm, ConfirmDialog, SubmitButton } from "@/components/forms";
import { Priority, StatusBadge, fmtDate, fmtDateTime, fmtSize } from "@/components/ui";
import { ServiceError, getRecordDetail } from "@/lib/records-service";
import { requirePermission } from "@/lib/session";
import {
  approveAction, archiveAction, deleteAction, noteAction, rejectAction, removeFileAction,
  reopenAction, restoreAction, uploadAction,
} from "../actions";

export const dynamic = "force-dynamic";
export async function generateMetadata() { return { title: "Record" }; }

const LABELS: Record<string, string> = {
  "record.created": "Created", "record.updated": "Edited", "record.approved": "Approved", "record.rejected": "Rejected",
  "record.reopened": "Reopened", "record.archived": "Archived", "record.restored": "Restored", "record.deleted": "Deleted",
  "record.note_added": "Added a note", "attachment.uploaded": "Uploaded a file", "attachment.downloaded": "Downloaded a file",
  "attachment.removed": "Removed a file",
};
const FIELD = { title: "title", description: "description", priority: "priority", categoryId: "category", departmentId: "department", status: "status" } as Record<string, string>;

function describe(action: string, detail: string | null) {
  if (!detail) return "";
  try {
    const d = JSON.parse(detail);
    if (action === "record.updated")
      return Object.entries(d as Record<string, [unknown, unknown]>)
        .map(([k, [a, b]]) => (["title", "priority", "status"].includes(k) ? `${FIELD[k]}: “${a}” → “${b}”` : `${FIELD[k] ?? k} changed`))
        .join("; ");
    if (d.file) return String(d.file);
    if (d.reason) return `Reason: ${d.reason}`;
    if (d.from) return `From ${d.from}`;
  } catch {}
  return "";
}

export default async function RecordPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ created?: string; saved?: string }> }) {
  const user = await requirePermission("records.view");
  const id = Number((await params).id);
  const sp = await searchParams;
  if (!Number.isInteger(id)) notFound();
  let d;
  try { d = getRecordDetail(user, id); } catch (e) { if (e instanceof ServiceError) notFound(); throw e; }
  const r = d.r;

  return (
    <>
      <div className="mb-2 text-sm"><Link href="/records" className="text-navy-700 hover:underline">← All records</Link></div>
      {(sp.created || sp.saved) && (
        <div role="status" className="mb-4 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
          {sp.created ? `Record created with reference ${r.refNo}.` : "Changes saved."}
        </div>
      )}

      <div className="mb-6 flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="font-mono text-xs text-slate-500">{r.refNo}</div>
          <h1 className="text-2xl font-bold text-navy-900">{r.title}</h1>
          <div className="mt-2 flex items-center gap-3"><StatusBadge status={r.status} /><Priority value={r.priority} />{r.isDemo && <span className="rounded bg-gold-100 px-1.5 py-0.5 text-[10px] font-bold uppercase text-gold-500">Demo data</span>}</div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {d.can.edit && <Link href={`/records/${id}/edit`} className="btn-ghost">Edit</Link>}
          {d.can.approve && (
            <>
              <ActionForm action={approveAction.bind(null, id)}>
                <ConfirmDialog label="Approve" title="Approve this record?" message="Approving locks the record against edits. This is logged against your name." confirmLabel="Approve" className="btn-primary" />
              </ActionForm>
              <ActionForm action={rejectAction.bind(null, id)}>
                <ConfirmDialog label="Reject" title="Reject this record?" message="The creator will be notified with your reason." confirmLabel="Reject" danger withReason />
              </ActionForm>
            </>
          )}
          {d.can.reopen && (
            <ActionForm action={reopenAction.bind(null, id)}>
              <ConfirmDialog label="Reopen" title="Reopen for editing?" message="The record returns to Pending and must be approved again after changes." confirmLabel="Reopen" withReason />
            </ActionForm>
          )}
          {d.can.archive && (
            <ActionForm action={archiveAction.bind(null, id)}>
              <ConfirmDialog label="Archive" title="Archive this record?" message="It will be hidden from normal lists but kept with its full history. You can restore it later." confirmLabel="Archive" />
            </ActionForm>
          )}
          {d.can.restore && (
            <ActionForm action={restoreAction.bind(null, id)}>
              <ConfirmDialog label="Restore" title="Restore this record?" message="It returns to the status it had before archiving." confirmLabel="Restore" />
            </ActionForm>
          )}
          {d.can.remove && (
            <ActionForm action={deleteAction.bind(null, id)}>
              <ConfirmDialog label="Delete" title="Delete this record?" message="It disappears from all lists. The deletion and your reason stay permanently in the audit trail." confirmLabel="Delete" danger withReason className="btn-ghost text-red-700" />
            </ActionForm>
          )}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <section className="card">
            <h2 className="mb-2 font-semibold text-navy-900">Description</h2>
            {r.description ? <p className="whitespace-pre-wrap text-sm text-slate-700">{r.description}</p> : <p className="text-sm text-slate-500">No description provided.</p>}
          </section>

          <section className="card" aria-labelledby="h-files">
            <h2 id="h-files" className="mb-3 font-semibold text-navy-900">Attachments</h2>
            {d.files.length === 0 ? <p className="text-sm text-slate-500">No files attached.</p> : (
              <ul className="divide-y divide-slate-100">
                {d.files.map((f) => (
                  <li key={f.id} className="flex items-center justify-between gap-3 py-2.5">
                    <div className="flex min-w-0 items-center gap-2 text-sm">
                      <Paperclip size={16} className="shrink-0 text-slate-400" />
                      <div className="min-w-0"><div className="truncate font-medium">{f.name}</div><div className="text-xs text-slate-500">{fmtSize(f.size)} · {f.by} · {fmtDate(f.createdAt)}</div></div>
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      {d.can.download && <a href={`/api/attachments/${f.id}`} className="btn-ghost px-3 py-1.5"><Download size={14} />Download</a>}
                      {d.can.upload && (
                        <ActionForm action={removeFileAction.bind(null, id, f.id)}>
                          <ConfirmDialog label="Remove" title="Remove this file?" message="The file is detached from the record but retained in secure storage for audit." confirmLabel="Remove" danger className="btn-ghost px-3 py-1.5 text-red-700" />
                        </ActionForm>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            )}
            {d.can.upload && (
              <ActionForm action={uploadAction.bind(null, id)} encType="multipart/form-data" className="mt-4 flex flex-wrap items-end gap-3 border-t border-slate-100 pt-4">
                <div className="min-w-0 flex-1">
                  <label htmlFor="file" className="label">Add a file (PDF, DOCX, XLSX, JPG or PNG, up to 10 MB)</label>
                  <input id="file" name="file" type="file" required accept=".pdf,.docx,.xlsx,.jpg,.jpeg,.png" className="input" />
                </div>
                <SubmitButton pendingText="Uploading…">Upload</SubmitButton>
              </ActionForm>
            )}
          </section>

          <section className="card" aria-labelledby="h-notes">
            <h2 id="h-notes" className="mb-3 font-semibold text-navy-900">Internal notes</h2>
            <ActionForm action={noteAction.bind(null, id)} className="mb-4">
              <label htmlFor="body" className="sr-only">New note</label>
              <textarea id="body" name="body" rows={2} required maxLength={5000} placeholder="Add an internal note" className="input" />
              <div className="mt-2"><SubmitButton className="btn-ghost">Add note</SubmitButton></div>
            </ActionForm>
            {d.notes.length === 0 ? <p className="text-sm text-slate-500">No notes yet.</p> : (
              <ul className="space-y-3">
                {d.notes.map((n) => (
                  <li key={n.id} className="rounded-md bg-slate-50 p-3 text-sm">
                    <p className="whitespace-pre-wrap">{n.body}</p>
                    <p className="mt-1 text-xs text-slate-500">{n.author} · {fmtDateTime(n.createdAt)}</p>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>

        <div className="space-y-6">
          <section className="card">
            <h2 className="mb-3 font-semibold text-navy-900">Details</h2>
            <dl className="space-y-2 text-sm">
              {[
                ["Category", d.category], ["Department", d.department], ["Created by", d.creator], ["Date created", fmtDateTime(r.createdAt)],
                ["Last updated", fmtDateTime(r.updatedAt)], ["Updated by", d.updater],
                ...(d.approver ? [["Approved by", `${d.approver} (${fmtDate(r.approvedAt)})`]] : []),
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between gap-4"><dt className="text-slate-500">{k}</dt><dd className="text-right font-medium">{v}</dd></div>
              ))}
            </dl>
          </section>
          <section className="card" aria-labelledby="h-hist">
            <h2 id="h-hist" className="mb-3 font-semibold text-navy-900">Activity history</h2>
            <ol className="space-y-3 border-l-2 border-gold-400 pl-4">
              {d.history.map((h) => (
                <li key={h.id} className="text-sm">
                  <div className="font-medium">{LABELS[h.action] ?? h.action}</div>
                  {describe(h.action, h.detail) && <div className="text-xs text-slate-600">{describe(h.action, h.detail)}</div>}
                  <div className="text-xs text-slate-500">{h.userEmail} · {fmtDateTime(h.at)}</div>
                </li>
              ))}
            </ol>
          </section>
        </div>
      </div>
    </>
  );
}
