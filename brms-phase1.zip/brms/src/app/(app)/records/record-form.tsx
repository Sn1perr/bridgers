import Link from "next/link";
import { ActionForm, SubmitButton, type FormAction } from "@/components/forms";
import { RECORD_PRIORITIES } from "@/lib/permissions";

type Opt = { id: number; name: string };

export function RecordForm({
  action,
  categories,
  departments,
  defaults,
  cancelHref,
  isNew,
  lockDepartment,
}: {
  action: FormAction;
  categories: Opt[];
  departments: Opt[];
  defaults?: { title: string; description: string; categoryId: number; departmentId: number; priority: string; status: string };
  cancelHref: string;
  isNew: boolean;
  lockDepartment?: boolean;
}) {
  const d = defaults;
  return (
    <ActionForm action={action} className="card max-w-3xl space-y-5">
      <div>
        <label htmlFor="title" className="label">Title <span className="text-red-700">*</span></label>
        <input id="title" name="title" required minLength={3} maxLength={200} defaultValue={d?.title} className="input" />
      </div>
      <div>
        <label htmlFor="description" className="label">Description</label>
        <textarea id="description" name="description" rows={5} maxLength={10000} defaultValue={d?.description} className="input" />
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="categoryId" className="label">Category <span className="text-red-700">*</span></label>
          <select id="categoryId" name="categoryId" required defaultValue={d?.categoryId} className="input">
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="departmentId" className="label">Department responsible <span className="text-red-700">*</span></label>
          <select id="departmentId" name="departmentId" required defaultValue={d?.departmentId} className="input">
            {departments.filter((x) => !lockDepartment || x.id === d?.departmentId).map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="priority" className="label">Priority</label>
          <select id="priority" name="priority" defaultValue={d?.priority ?? "Normal"} className="input">
            {RECORD_PRIORITIES.map((p) => <option key={p}>{p}</option>)}
          </select>
        </div>
        {(isNew || ["Active", "Pending", "Rejected"].includes(d?.status ?? "")) && (
          <div>
            <label htmlFor="status" className="label">Status</label>
            <select id="status" name="status" defaultValue={d?.status === "Active" ? "Active" : "Pending"} className="input">
              <option value="Pending">Pending (send for approval)</option>
              <option value="Active">Active (no approval needed)</option>
            </select>
            <p className="mt-1 text-xs text-slate-500">Approval and rejection are done by an authorised approver from the record page.</p>
          </div>
        )}
      </div>
      {isNew && (
        <label className="flex items-center gap-2 text-sm text-slate-700">
          <input type="checkbox" name="allowDuplicate" className="h-4 w-4" />
          Create anyway if a record with the same title already exists in this category
        </label>
      )}
      <div className="flex gap-2 border-t border-slate-100 pt-4">
        <SubmitButton>{isNew ? "Create record" : "Save changes"}</SubmitButton>
        <Link href={cancelHref} className="btn-ghost">Cancel</Link>
      </div>
    </ActionForm>
  );
}
