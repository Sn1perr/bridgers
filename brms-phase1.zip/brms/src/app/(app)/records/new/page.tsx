import { PageHeader } from "@/components/ui";
import { listCategories, listDepartments } from "@/lib/records-service";
import { requirePermission } from "@/lib/session";
import { createRecordAction } from "../actions";
import { RecordForm } from "../record-form";

export const metadata = { title: "New record" };

export default async function NewRecord() {
  const user = await requirePermission("records.create");
  const viewAll = user.permissions.has("records.view_all");
  const deps = listDepartments();
  return (
    <>
      <PageHeader title="New record" subtitle="A unique reference number is assigned automatically when you save." />
      <RecordForm
        action={createRecordAction}
        categories={listCategories()}
        departments={viewAll || !user.departmentId ? deps : deps.filter((d) => d.id === user.departmentId)}
        defaults={{ title: "", description: "", categoryId: listCategories()[0]?.id ?? 0, departmentId: user.departmentId ?? deps[0]?.id ?? 0, priority: "Normal", status: "Pending" }}
        cancelHref="/records"
        isNew
      />
    </>
  );
}
