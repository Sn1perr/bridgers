"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import type { FormState } from "@/components/forms";
import {
  ServiceError, addAttachment, addNote, archiveRecord, createRecord, decide, deleteRecord,
  removeAttachment, reopen, restoreRecord, updateRecord,
} from "@/lib/records-service";
import { requireUser } from "@/lib/session";

const s = (fd: FormData, k: string) => String(fd.get(k) ?? "");
const n = (fd: FormData, k: string) => Number(fd.get(k) ?? 0);

async function run(fn: () => string | void, ok?: string): Promise<FormState> {
  try {
    fn();
    return { error: null, ok };
  } catch (e) {
    if (e instanceof ServiceError) return { error: e.message };
    console.error(e);
    return { error: "Something went wrong. Please try again, and contact the administrator if it continues." };
  }
}

export async function createRecordAction(_: FormState, fd: FormData): Promise<FormState> {
  const user = await requireUser();
  let id = 0;
  const res = await run(() => {
    id = createRecord(
      user,
      { title: s(fd, "title"), description: s(fd, "description"), categoryId: n(fd, "categoryId"), departmentId: n(fd, "departmentId"), priority: s(fd, "priority"), status: s(fd, "status") || "Pending" },
      { allowDuplicate: fd.get("allowDuplicate") === "on" },
    ).id;
  });
  if (res.error) return res;
  redirect(`/records/${id}?created=1`);
}

export async function updateRecordAction(id: number, _: FormState, fd: FormData): Promise<FormState> {
  const user = await requireUser();
  const res = await run(() => {
    updateRecord(user, id, { title: s(fd, "title"), description: s(fd, "description"), categoryId: n(fd, "categoryId"), departmentId: n(fd, "departmentId"), priority: s(fd, "priority"), status: s(fd, "status") || undefined });
  });
  if (res.error) return res;
  revalidatePath(`/records/${id}`);
  redirect(`/records/${id}?saved=1`);
}

async function simple(id: number, fn: (u: Awaited<ReturnType<typeof requireUser>>) => void, ok: string): Promise<FormState> {
  const user = await requireUser();
  const res = await run(() => fn(user), ok);
  if (!res.error) revalidatePath(`/records/${id}`);
  return res;
}

export const approveAction = async (id: number, _: FormState): Promise<FormState> => simple(id, (u) => decide(u, id, "Approved"), "Record approved.");
export const rejectAction = async (id: number, _: FormState, fd: FormData): Promise<FormState> => simple(id, (u) => decide(u, id, "Rejected", s(fd, "reason")), "Record rejected.");
export const reopenAction = async (id: number, _: FormState, fd: FormData): Promise<FormState> => simple(id, (u) => reopen(u, id, s(fd, "reason")), "Record reopened for editing.");
export const archiveAction = async (id: number, _: FormState): Promise<FormState> => simple(id, (u) => archiveRecord(u, id), "Record archived.");
export const restoreAction = async (id: number, _: FormState): Promise<FormState> => simple(id, (u) => restoreRecord(u, id), "Record restored.");
export const noteAction = async (id: number, _: FormState, fd: FormData): Promise<FormState> => simple(id, (u) => addNote(u, id, s(fd, "body")), "Note added.");
export const removeFileAction = async (id: number, fileId: number, _: FormState): Promise<FormState> => simple(id, (u) => removeAttachment(u, fileId), "File removed.");

export async function deleteAction(id: number, _: FormState, fd: FormData): Promise<FormState> {
  const user = await requireUser();
  const res = await run(() => deleteRecord(user, id, s(fd, "reason")));
  if (res.error) return res;
  redirect("/records?deleted=1");
}

export async function uploadAction(id: number, _: FormState, fd: FormData): Promise<FormState> {
  const user = await requireUser();
  const file = fd.get("file");
  if (!(file instanceof File) || file.size === 0) return { error: "Choose a file to upload." };
  const buf = Buffer.from(await file.arrayBuffer());
  const res = await run(() => { addAttachment(user, id, file.name, buf); }, "File uploaded.");
  if (!res.error) revalidatePath(`/records/${id}`);
  return res;
}
