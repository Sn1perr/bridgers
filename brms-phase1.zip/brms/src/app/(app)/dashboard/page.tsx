import Link from "next/link";
import { CategoryChart, StatusChart, TrendChart } from "@/components/charts";
import { Empty, PageHeader, Stat, StatusBadge, fmtDateTime } from "@/components/ui";
import { getDashboard } from "@/lib/dashboard-service";
import { RECORD_STATUSES } from "@/lib/permissions";
import { requirePermission } from "@/lib/session";

export const metadata = { title: "Dashboard" };
export const dynamic = "force-dynamic";

export default async function Dashboard({ searchParams }: { searchParams: Promise<{ denied?: string }> }) {
  const user = await requirePermission("dashboard.view");
  const sp = await searchParams;
  const d = getDashboard(user);
  const first = user.name.split(" ")[0];

  return (
    <>
      <PageHeader
        title={`Welcome, ${first}`}
        subtitle="Figures below are calculated live from the records you are permitted to see."
        actions={user.permissions.has("records.create") ? <Link href="/records/new" className="btn-gold">New record</Link> : undefined}
      />
      {sp.denied && (
        <div role="alert" className="mb-4 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
          You do not have access to that page.
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Total records" value={d.total} hint={`${d.byStatus.Archived ?? 0} archived`} href="/records" />
        <Stat label="Pending approval" value={d.byStatus.Pending ?? 0} tone="gold" href="/records?status=Pending" hint={d.awaitingMyApproval !== null ? `${d.awaitingMyApproval} awaiting your decision` : undefined} />
        <Stat label="Approved" value={d.byStatus.Approved ?? 0} href="/records?status=Approved" />
        <Stat label="Urgent and open" value={d.urgentOpen} tone={d.urgentOpen ? "red" : "navy"} hint="Urgent priority, Active or Pending" />
        {d.people !== null && <Stat label="Active users" value={d.people} href="/settings/users" />}
        <Stat label="Rejected" value={d.byStatus.Rejected ?? 0} href="/records?status=Rejected" />
        <Stat label="Unread notifications" value={d.unread} href="/notifications" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <section className="card" aria-labelledby="h-status">
          <h2 id="h-status" className="mb-2 font-semibold text-navy-900">Records by status</h2>
          <StatusChart data={RECORD_STATUSES.map((s) => ({ status: s, count: d.byStatus[s] ?? 0 }))} />
        </section>
        <section className="card" aria-labelledby="h-trend">
          <h2 id="h-trend" className="mb-2 font-semibold text-navy-900">Records created per month</h2>
          <TrendChart data={d.trend} />
        </section>
        <section className="card" aria-labelledby="h-cat">
          <h2 id="h-cat" className="mb-2 font-semibold text-navy-900">Top categories (excluding archived)</h2>
          <CategoryChart data={d.byCategory.map((c) => ({ name: c.name, count: c.n }))} />
        </section>
        <section className="card" aria-labelledby="h-recent">
          <h2 id="h-recent" className="mb-3 font-semibold text-navy-900">Recent activity</h2>
          {d.recent.length === 0 ? (
            <Empty title="Nothing here yet" hint="Records you create or update will show up here." />
          ) : (
            <ul className="divide-y divide-slate-100">
              {d.recent.map((r) => (
                <li key={r.id} className="flex items-center justify-between gap-3 py-2.5">
                  <div className="min-w-0">
                    <Link href={`/records/${r.id}`} className="block truncate text-sm font-medium text-navy-800 hover:underline">{r.refNo} · {r.title}</Link>
                    <span className="text-xs text-slate-500">{r.by} · {fmtDateTime(r.updatedAt)}</span>
                  </div>
                  <StatusBadge status={r.status} />
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
      <p className="mt-6 text-xs text-slate-500">
        Cards for employees, projects, finance, documents, procurement and meetings will appear here as those modules are switched on in later phases.
      </p>
    </>
  );
}
