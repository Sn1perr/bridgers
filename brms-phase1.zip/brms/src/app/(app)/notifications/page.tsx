import Link from "next/link";
import { and, desc, eq, isNull } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db, schema } from "@/db";
import { Empty, PageHeader, fmtDateTime } from "@/components/ui";
import { requireUser } from "@/lib/session";

export const metadata = { title: "Notifications" };
export const dynamic = "force-dynamic";

async function markAllRead() {
  "use server";
  const user = await requireUser();
  db.update(schema.notifications).set({ readAt: new Date().toISOString() }).where(and(eq(schema.notifications.userId, user.id), isNull(schema.notifications.readAt))).run();
  revalidatePath("/", "layout");
}

export default async function NotificationsPage() {
  const user = await requireUser();
  const rows = db.select().from(schema.notifications).where(eq(schema.notifications.userId, user.id)).orderBy(desc(schema.notifications.id)).limit(50).all();
  const unread = rows.filter((r) => !r.readAt).length;
  return (
    <>
      <PageHeader title="Notifications" subtitle={unread ? `${unread} unread` : "You are all caught up."} actions={unread ? <form action={markAllRead}><button className="btn-ghost">Mark all as read</button></form> : undefined} />
      {rows.length === 0 ? (
        <Empty title="No notifications" hint="You will be told here when a record you created is approved or rejected." />
      ) : (
        <ul className="card divide-y divide-slate-100 p-0">
          {rows.map((n) => (
            <li key={n.id} className={`flex items-start gap-3 px-4 py-3 ${n.readAt ? "" : "bg-gold-100/40"}`}>
              <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${n.readAt ? "bg-slate-300" : "bg-gold-500"}`} aria-hidden />
              <div className="min-w-0">
                {n.href ? <Link href={n.href} className="font-medium text-navy-800 hover:underline">{n.title}</Link> : <span className="font-medium">{n.title}</span>}
                {n.body && <div className="truncate text-sm text-slate-600">{n.body}</div>}
                <div className="text-xs text-slate-500">{fmtDateTime(n.createdAt)}{n.readAt ? "" : " · unread"}</div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
