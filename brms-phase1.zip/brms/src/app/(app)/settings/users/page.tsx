import { revalidatePath } from "next/cache";
import { ActionForm, ConfirmDialog, SubmitButton, type FormState } from "@/components/forms";
import { PageHeader, fmtDateTime } from "@/components/ui";
import { adminCreateUser, adminResetPassword, adminSetActive, adminUpdateUser, listUsers } from "@/lib/admin-service";
import { ROLES } from "@/lib/permissions";
import { ServiceError, listDepartments } from "@/lib/records-service";
import { requirePermission } from "@/lib/session";

export const metadata = { title: "Users" };
export const dynamic = "force-dynamic";

async function guard(fn: () => void, ok: string): Promise<FormState> {
  try { fn(); revalidatePath("/settings/users"); return { error: null, ok }; }
  catch (e) { if (e instanceof ServiceError) return { error: e.message }; throw e; }
}
async function create(_: FormState, fd: FormData) {
  "use server";
  const u = await requirePermission("users.manage");
  return guard(() => { adminCreateUser(u, { name: String(fd.get("name")), email: String(fd.get("email")), role: String(fd.get("role")), departmentId: Number(fd.get("departmentId")), password: String(fd.get("password")) }); }, "User created. Give them the temporary password; they must change it at first sign-in.");
}
async function update(id: number, _: FormState, fd: FormData) {
  "use server";
  const u = await requirePermission("users.manage");
  return guard(() => adminUpdateUser(u, id, { role: String(fd.get("role")), departmentId: Number(fd.get("departmentId")) }), "User updated.");
}
async function setActive(id: number, active: boolean, _: FormState) {
  "use server";
  const u = await requirePermission("users.manage");
  return guard(() => adminSetActive(u, id, active), active ? "User reactivated." : "User deactivated and signed out.");
}
async function reset(id: number, _: FormState, fd: FormData) {
  "use server";
  const u = await requirePermission("users.manage");
  return guard(() => adminResetPassword(u, id, String(fd.get("password"))), "Password reset. The user must change it at next sign-in.");
}

export default async function UsersPage() {
  const me = await requirePermission("users.manage");
  const users = listUsers();
  const deps = listDepartments();
  const depId = (name: string | null) => deps.find((d) => d.name === name)?.id;
  const roleOptions = Object.entries(ROLES).filter(([k]) => k !== "super_admin" || me.role === "super_admin");
  return (
    <>
      <PageHeader title="Users" subtitle="Accounts, roles and departments. Passwords are never visible to anyone." />
      <ActionForm action={create} className="card mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <h2 className="font-semibold text-navy-900 sm:col-span-2 lg:col-span-3">Add a user</h2>
        <div><label htmlFor="name" className="label">Full name</label><input id="name" name="name" required className="input" /></div>
        <div><label htmlFor="email" className="label">Work email</label><input id="email" name="email" type="email" required className="input" /></div>
        <div><label htmlFor="password" className="label">Temporary password</label><input id="password" name="password" type="text" autoComplete="off" required minLength={10} className="input" /></div>
        <div><label htmlFor="role" className="label">Role</label><select id="role" name="role" defaultValue="staff" className="input">{roleOptions.map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></div>
        <div><label htmlFor="departmentId" className="label">Department</label><select id="departmentId" name="departmentId" className="input">{deps.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
        <div className="flex items-end"><SubmitButton>Create user</SubmitButton></div>
      </ActionForm>

      <div className="space-y-3">
        {users.map((u) => (
          <section key={u.id} className={`card ${u.active ? "" : "opacity-70"}`}>
            <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
              <div>
                <div className="font-semibold text-navy-900">{u.name} {!u.active && <span className="ml-1 rounded bg-slate-200 px-2 py-0.5 text-xs">Inactive</span>}</div>
                <div className="text-sm text-slate-600">{u.email} · last sign-in {fmtDateTime(u.lastLoginAt)}</div>
              </div>
            </div>
            <ActionForm action={update.bind(null, u.id)} className="flex flex-wrap items-end gap-3">
              <div><label htmlFor={`role-${u.id}`} className="label">Role</label>
                <select id={`role-${u.id}`} name="role" defaultValue={u.role} className="input">{Object.entries(ROLES).map(([k, v]) => <option key={k} value={k} disabled={k === "super_admin" && me.role !== "super_admin"}>{v}</option>)}</select></div>
              <div><label htmlFor={`dep-${u.id}`} className="label">Department</label>
                <select id={`dep-${u.id}`} name="departmentId" defaultValue={depId(u.department)} className="input">{deps.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
              <SubmitButton className="btn-ghost">Save</SubmitButton>
            </ActionForm>
            <div className="mt-3 flex flex-wrap gap-2 border-t border-slate-100 pt-3">
              <ActionForm action={reset.bind(null, u.id)} className="flex flex-wrap items-end gap-2">
                <div><label htmlFor={`pw-${u.id}`} className="label">Reset password to</label><input id={`pw-${u.id}`} name="password" type="text" autoComplete="off" minLength={10} required className="input w-56" /></div>
                <SubmitButton className="btn-ghost">Reset</SubmitButton>
              </ActionForm>
              {u.id !== me.id && (
                <ActionForm action={setActive.bind(null, u.id, !u.active)} className="ml-auto self-end">
                  <ConfirmDialog label={u.active ? "Deactivate" : "Reactivate"} title={u.active ? `Deactivate ${u.name}?` : `Reactivate ${u.name}?`} message={u.active ? "They are signed out immediately and cannot sign in. Their records and history are kept." : "They will be able to sign in again."} confirmLabel={u.active ? "Deactivate" : "Reactivate"} danger={u.active} className={u.active ? "btn-ghost text-red-700" : "btn-ghost"} />
                </ActionForm>
              )}
            </div>
          </section>
        ))}
      </div>
    </>
  );
}
