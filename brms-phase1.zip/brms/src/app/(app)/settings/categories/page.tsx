import { revalidatePath } from "next/cache";
import { ActionForm, SubmitButton, type FormState } from "@/components/forms";
import { PageHeader } from "@/components/ui";
import { ServiceError, createCategory, listCategories, setCategoryActive } from "@/lib/records-service";
import { requirePermission } from "@/lib/session";

export const metadata = { title: "Record categories" };
export const dynamic = "force-dynamic";

async function add(_: FormState, fd: FormData): Promise<FormState> {
  "use server";
  const user = await requirePermission("categories.manage");
  try { createCategory(user, String(fd.get("name") ?? "")); } catch (e) { if (e instanceof ServiceError) return { error: e.message }; throw e; }
  revalidatePath("/settings/categories");
  return { error: null, ok: "Category added." };
}
async function toggle(id: number, active: boolean) {
  "use server";
  const user = await requirePermission("categories.manage");
  setCategoryActive(user, id, active);
  revalidatePath("/settings/categories");
}

export default async function Categories() {
  await requirePermission("categories.manage");
  const cats = listCategories(false);
  return (
    <>
      <PageHeader title="Record categories" subtitle="Disabling a category hides it from new records; existing records keep it." />
      <ActionForm action={add} className="card mb-6 flex max-w-xl flex-wrap items-end gap-3">
        <div className="min-w-0 flex-1">
          <label htmlFor="name" className="label">New category name</label>
          <input id="name" name="name" required minLength={2} maxLength={60} className="input" />
        </div>
        <SubmitButton>Add category</SubmitButton>
      </ActionForm>
      <ul className="card max-w-xl divide-y divide-slate-100 p-0">
        {cats.map((c) => (
          <li key={c.id} className="flex items-center justify-between px-4 py-3 text-sm">
            <span className={c.active ? "font-medium" : "text-slate-400 line-through"}>{c.name}</span>
            <form action={toggle.bind(null, c.id, !c.active)}><button className="btn-ghost px-3 py-1.5">{c.active ? "Disable" : "Enable"}</button></form>
          </li>
        ))}
      </ul>
    </>
  );
}
