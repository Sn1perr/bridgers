import Link from "next/link";
import { and, desc, eq, like, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { Empty, PageHeader, fmtDateTime } from "@/components/ui";
import { requirePermission } from "@/lib/session";

export const metadata = { title: "Audit log" };
export const dynamic = "force-dynamic";

export default async function Audit({ searchParams }: { searchParams: Promise<{ q?: string; action?: string; page?: string }> }) {
  await requirePermission("audit.view");
  const sp = await searchParams;
  const page = Math.max(1, Number(sp.page) || 1);
  const size = 30;
  const conds = [];
  if (sp.action) conds.push(like(schema.auditLogs.action, `${sp.action.replace(/[%_\\]/g, "")}%`));
  if (sp.q) conds.push(like(schema.auditLogs.userEmail, `%${sp.q.replace(/[%_\\]/g, "")}%`));
  const where = conds.length ? and(...conds) : undefined;
  const total = db.select({ n: sql<number>`count(*)` }).from(schema.auditLogs).where(where).get()!.n;
  const rows = db.select().from(schema.auditLogs).where(where).orderBy(desc(schema.auditLogs.id)).limit(size).offset((page - 1) * size).all();
  const pages = Math.max(1, Math.ceil(total / size));
  const qs = (p: number) => { const q = new URLSearchParams(); if (sp.q) q.set("q", sp.q); if (sp.action) q.set("action", sp.action); q.set("page", String(p)); return `?${q}`; };
  void eq;
  return (
    <>
      <PageHeader title="Audit log" subtitle={`${total} entries. This log is append-only: nobody, including administrators, can edit or erase entries.`} />
      <form className="card mb-4 flex flex-wrap items-end gap-3" aria-label="Filter audit log">
        <div><label htmlFor="q" className="label">User email</label><input id="q" name="q" defaultValue={sp.q} className="input" /></div>
        <div>
          <label htmlFor="action" className="label">Event type</label>
          <select id="action" name="action" defaultValue={sp.action ?? ""} className="input">
            <option value="">All</option>
            {["login", "logout", "password", "record", "attachment", "category", "user", "role"].map((a) => <option key={a} value={a}>{a}</option>)}
          </select>
        </div>
        <button className="btn-primary">Filter</button>
      </form>
      {rows.length === 0 ? <Empty title="No entries match" /> : (
        <div className="card overflow-hidden p-0">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px]">
              <thead className="border-b border-slate-200 bg-slate-50"><tr>
                {["When", "User", "Event", "Item", "Details", "IP"].map((h) => <th key={h} className="th" scope="col">{h}</th>)}
              </tr></thead>
              <tbody className="divide-y divide-slate-100">
                {rows.map((r) => (
                  <tr key={r.id}>
                    <td className="td whitespace-nowrap text-slate-600">{fmtDateTime(r.at)}</td>
                    <td className="td">{r.userEmail ?? "system"}</td>
                    <td className="td font-mono text-xs">{r.action}</td>
                    <td className="td text-xs">{r.entity}{r.entityId ? ` #${r.entityId}` : ""}</td>
                    <td className="td max-w-xs truncate text-xs text-slate-600" title={r.detail ?? ""}>{r.detail ?? ""}</td>
                    <td className="td text-xs text-slate-500">{r.ip ?? ""}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex items-center justify-between border-t border-slate-200 px-4 py-3 text-sm">
            <span className="text-slate-600">Page {page} of {pages}</span>
            <div className="flex gap-2">
              {page > 1 && <Link className="btn-ghost" href={qs(page - 1)}>Previous</Link>}
              {page < pages && <Link className="btn-ghost" href={qs(page + 1)}>Next</Link>}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
