import { revalidatePath } from "next/cache";
import { ActionForm, SubmitButton, type FormState } from "@/components/forms";
import { PageHeader } from "@/components/ui";
import { getRoleMatrix, setRolePermissions } from "@/lib/admin-service";
import { PERMISSIONS, ROLES, ROLE_KEYS } from "@/lib/permissions";
import { ServiceError } from "@/lib/records-service";
import { requirePermission } from "@/lib/session";

export const metadata = { title: "Roles and permissions" };
export const dynamic = "force-dynamic";

async function save(role: string, _: FormState, fd: FormData): Promise<FormState> {
  "use server";
  const u = await requirePermission("roles.manage");
  try { setRolePermissions(u, role, fd.getAll("perm").map(String)); }
  catch (e) { if (e instanceof ServiceError) return { error: e.message }; throw e; }
  revalidatePath("/settings/roles");
  return { error: null, ok: `Permissions for ${ROLES[role as keyof typeof ROLES]} saved. They apply on the user's next page load.` };
}

export default async function RolesPage() {
  await requirePermission("roles.manage");
  const matrix = getRoleMatrix();
  return (
    <>
      <PageHeader title="Roles and permissions" subtitle="Tick what each role may do. Every change is written to the audit log." />
      <div className="grid gap-4 lg:grid-cols-2">
        {ROLE_KEYS.map((role) => {
          const locked = role === "super_admin";
          const has = matrix.get(role) ?? new Set<string>();
          return (
            <ActionForm key={role} action={save.bind(null, role)} className="card">
              <h2 className="font-semibold text-navy-900">{ROLES[role]}</h2>
              {locked && <p className="mb-2 text-xs text-slate-500">Always has every permission and cannot be changed.</p>}
              <fieldset disabled={locked} className="mt-2 space-y-1.5">
                <legend className="sr-only">Permissions for {ROLES[role]}</legend>
                {Object.entries(PERMISSIONS).map(([k, label]) => (
                  <label key={k} className="flex items-center gap-2 text-sm">
                    <input type="checkbox" name="perm" value={k} defaultChecked={locked || has.has(k)} className="h-4 w-4" />
                    {label}
                  </label>
                ))}
              </fieldset>
              {!locked && <div className="mt-4"><SubmitButton className="btn-ghost">Save permissions</SubmitButton></div>}
            </ActionForm>
          );
        })}
      </div>
    </>
  );
}
