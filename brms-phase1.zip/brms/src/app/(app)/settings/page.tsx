import Link from "next/link";
import { PageHeader } from "@/components/ui";
import { requireUser } from "@/lib/session";

export const metadata = { title: "Settings" };

export default async function Settings() {
  const user = await requireUser();
  const p = user.permissions;
  const items = [
    p.has("users.manage") && { href: "/settings/users", title: "Users", text: "Create accounts, assign roles and departments, deactivate users and issue password resets." },
    p.has("roles.manage") && { href: "/settings/roles", title: "Roles and permissions", text: "Choose exactly what each role is allowed to do." },
    p.has("categories.manage") && { href: "/settings/categories", title: "Record categories", text: "Add categories to suit the way the company works." },
    p.has("audit.view") && { href: "/settings/audit", title: "Audit log", text: "A permanent, read-only history of sign-ins, edits, approvals and downloads." },
  ].filter(Boolean) as { href: string; title: string; text: string }[];
  return (
    <>
      <PageHeader title="Settings" />
      <div className="grid gap-4 sm:grid-cols-2">
        {items.map((i) => (
          <Link key={i.href} href={i.href} className="card block transition hover:border-gold-500 hover:shadow-md">
            <div className="font-semibold text-navy-900">{i.title}</div>
            <p className="mt-1 text-sm text-slate-600">{i.text}</p>
          </Link>
        ))}
      </div>
    </>
  );
}
