import { redirect } from "next/navigation";
import { Shell, type NavItem } from "@/components/shell";
import { Logo } from "@/components/ui";
import { unreadCount } from "@/lib/dashboard-service";
import { ROLES } from "@/lib/permissions";
import { clearSession, requireUser } from "@/lib/session";

async function signOut() {
  "use server";
  const { getUser } = await import("@/lib/session");
  await clearSession(await getUser());
  redirect("/login");
}

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  const p = user.permissions;
  // Only modules that are built AND permitted for this user are shown.
  const nav: NavItem[] = [];
  if (p.has("dashboard.view")) nav.push({ href: "/dashboard", label: "Dashboard", icon: "dashboard" });
  if (p.has("records.view")) nav.push({ href: "/records", label: "Records", icon: "records" });
  nav.push({ href: "/notifications", label: "Notifications", icon: "notifications" });
  if (p.has("users.manage") || p.has("roles.manage") || p.has("audit.view") || p.has("categories.manage"))
    nav.push({ href: "/settings", label: "Settings", icon: "settings" });
  return (
    <Shell nav={nav} user={{ name: user.name, role: ROLES[user.role] ?? user.role }} unread={unreadCount(user.id)} logo={<Logo light />} logoutAction={signOut}>
      {children}
    </Shell>
  );
}
