import Link from "next/link";
import { Empty, PageHeader, StatusBadge } from "@/components/ui";
import { listRecords } from "@/lib/records-service";
import { requirePermission } from "@/lib/session";

export const metadata = { title: "Search" };
export const dynamic = "force-dynamic";

export default async function SearchPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const user = await requirePermission("records.view");
  const q = ((await searchParams).q ?? "").trim();
  // Search spans every status, including archived, but only records this user may see.
  const rows = q ? [...listRecords(user, { q, pageSize: 50 }).rows, ...listRecords(user, { q, status: "Archived", pageSize: 50 }).rows] : [];
  return (
    <>
      <PageHeader title="Search" subtitle={q ? `${rows.length} result${rows.length === 1 ? "" : "s"} for “${q}”` : "Type in the search box above to find records."} />
      {!q ? (
        <Empty title="Start typing to search" hint="Search matches record titles, reference numbers and descriptions. More modules (employees, projects, clients, documents) join the search as they are added." />
      ) : rows.length === 0 ? (
        <Empty title="Nothing found" hint="Check the spelling or try fewer words." />
      ) : (
        <ul className="card divide-y divide-slate-100 p-0">
          {rows.map((r) => (
            <li key={r.id} className="flex items-center justify-between gap-3 px-4 py-3">
              <div className="min-w-0">
                <Link href={`/records/${r.id}`} className="block truncate font-medium text-navy-800 hover:underline">{r.title}</Link>
                <span className="font-mono text-xs text-slate-500">{r.refNo}</span>
                <span className="text-xs text-slate-500"> · {r.category} · {r.department}</span>
              </div>
              <StatusBadge status={r.status} />
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
