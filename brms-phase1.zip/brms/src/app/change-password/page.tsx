import { redirect } from "next/navigation";
import { ActionForm, SubmitButton, type FormState } from "@/components/forms";
import { Logo } from "@/components/ui";
import { changePassword } from "@/lib/auth-core";
import { clearSession, requireUser } from "@/lib/session";

export const metadata = { title: "Change password" };

async function change(_: FormState, fd: FormData): Promise<FormState> {
  "use server";
  const user = await requireUser({ allowMustChange: true });
  const next = String(fd.get("next") ?? "");
  if (next !== String(fd.get("confirm") ?? "")) return { error: "The new passwords do not match." };
  const res = changePassword(user.id, String(fd.get("current") ?? ""), next, user);
  if (!res.ok) return { error: res.error };
  // All sessions were revoked on change; ask the user to sign in again with the new password.
  await clearSession(null);
  redirect("/login");
}

export default async function ChangePasswordPage() {
  const user = await requireUser({ allowMustChange: true });
  return (
    <div className="flex min-h-screen items-center justify-center p-6">
      <div className="w-full max-w-md card">
        <Logo />
        <h1 className="mt-6 text-xl font-bold text-navy-900">{user.mustChangePassword ? "Set a new password" : "Change password"}</h1>
        {user.mustChangePassword && <p className="mt-1 text-sm text-slate-600">For security, you must replace your temporary password before continuing.</p>}
        <ActionForm action={change} className="mt-5 space-y-4">
          <div>
            <label htmlFor="current" className="label">Current password</label>
            <input id="current" name="current" type="password" autoComplete="current-password" required className="input" />
          </div>
          <div>
            <label htmlFor="next" className="label">New password</label>
            <input id="next" name="next" type="password" autoComplete="new-password" required minLength={10} className="input" />
            <p className="mt-1 text-xs text-slate-500">At least 10 characters with upper and lower case letters, a number and a symbol.</p>
          </div>
          <div>
            <label htmlFor="confirm" className="label">Confirm new password</label>
            <input id="confirm" name="confirm" type="password" autoComplete="new-password" required className="input" />
          </div>
          <SubmitButton className="btn-primary w-full">Update password</SubmitButton>
        </ActionForm>
      </div>
    </div>
  );
}
