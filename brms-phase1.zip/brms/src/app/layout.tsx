import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "BRMS | Bridgers Resources Limited", template: "%s | BRMS" },
  description: "Bridgers Resource Management System: secure company record keeping.",
  robots: { index: false, follow: false },
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#0b1b3d" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-NG">
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
