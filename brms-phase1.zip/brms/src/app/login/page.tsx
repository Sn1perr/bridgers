import { redirect } from "next/navigation";
import { ShieldCheck } from "lucide-react";
import { ActionForm, SubmitButton, type FormState } from "@/components/forms";
import { Logo } from "@/components/ui";
import { loginWithPassword } from "@/lib/auth-core";
import { clientIp, getUser, setSessionCookie } from "@/lib/session";

export const metadata = { title: "Sign in" };

async function login(_: FormState, fd: FormData): Promise<FormState> {
  "use server";
  const email = String(fd.get("email") ?? "");
  const password = String(fd.get("password") ?? "");
  if (!email || !password) return { error: "Enter your email and password." };
  const res = loginWithPassword(email, password, await clientIp());
  if (!res.ok) return { error: res.error };
  await setSessionCookie(res.token);
  redirect(res.user.mustChangePassword ? "/change-password" : "/dashboard");
}

export default async function LoginPage() {
  if (await getUser()) redirect("/dashboard");
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="hidden flex-col justify-between bg-navy-900 p-12 text-white lg:flex">
        <Logo light size={52} />
        <div>
          <div className="mb-4 h-1 w-16 bg-gold-500" />
          <h1 className="text-4xl font-bold leading-tight">Every record.<br />Accounted for.</h1>
          <p className="mt-4 max-w-md text-navy-100">
            The Bridgers Resource Management System keeps company records organised, protected and easy to find, with a full audit trail behind every change.
          </p>
        </div>
        <p className="text-xs text-navy-100">© Bridgers Resources Limited. Authorised users only. Activity is logged.</p>
      </div>
      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <div className="mb-8 lg:hidden"><Logo /></div>
          <h2 className="text-2xl font-bold text-navy-900">Sign in</h2>
          <p className="mt-1 text-sm text-slate-600">Use your company account to continue.</p>
          <ActionForm action={login} className="mt-6 space-y-4">
            <div>
              <label htmlFor="email" className="label">Work email</label>
              <input id="email" name="email" type="email" autoComplete="username" required className="input" />
            </div>
            <div>
              <label htmlFor="password" className="label">Password</label>
              <input id="password" name="password" type="password" autoComplete="current-password" required className="input" />
            </div>
            <SubmitButton className="btn-primary w-full" pendingText="Signing in…">Sign in</SubmitButton>
          </ActionForm>
          <p className="mt-6 flex items-start gap-2 text-xs text-slate-500">
            <ShieldCheck size={14} className="mt-0.5 shrink-0 text-gold-500" />
            Forgotten your password? Contact your Super Administrator, who can issue a one-time reset.
          </p>
        </div>
      </div>
    </div>
  );
}
