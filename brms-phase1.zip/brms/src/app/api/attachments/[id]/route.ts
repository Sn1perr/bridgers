import { NextResponse } from "next/server";
import { ServiceError, openAttachment } from "@/lib/records-service";
import { getUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getUser();
  if (!user || user.mustChangePassword) return new NextResponse("Unauthorised", { status: 401 });
  const id = Number((await ctx.params).id);
  if (!Number.isInteger(id)) return new NextResponse("Not found", { status: 404 });
  try {
    const f = openAttachment(user, id); // checks permission and record visibility, writes an audit entry
    const asciiName = f.name.replace(/[^\x20-\x7e]/g, "_").replace(/["\\]/g, "_");
    return new NextResponse(new Uint8Array(f.data), {
      headers: {
        "Content-Type": f.mime,
        "Content-Disposition": `attachment; filename="${asciiName}"; filename*=UTF-8''${encodeURIComponent(f.name)}`,
        "X-Content-Type-Options": "nosniff",
        "Cache-Control": "private, no-store",
        "Content-Security-Policy": "default-src 'none'; sandbox",
      },
    });
  } catch (e) {
    if (e instanceof ServiceError) return new NextResponse("Not found", { status: 404 });
    throw e;
  }
}
