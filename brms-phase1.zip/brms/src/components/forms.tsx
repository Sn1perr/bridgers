"use client";

import { useActionState, useRef } from "react";
import { useFormStatus } from "react-dom";

export type FormState = { error: string | null; ok?: string | null };
export type FormAction = (prev: FormState, fd: FormData) => Promise<FormState>;

export function SubmitButton({ children, className = "btn-primary", pendingText = "Working…" }: { children: React.ReactNode; className?: string; pendingText?: string }) {
  const { pending } = useFormStatus();
  return (
    <button type="submit" className={className} disabled={pending} aria-busy={pending}>
      {pending ? pendingText : children}
    </button>
  );
}

export function ActionForm({ action, children, className, encType }: { action: FormAction; children: React.ReactNode; className?: string; encType?: string }) {
  const [state, formAction] = useActionState(action, { error: null, ok: null } as FormState);
  const ref = useRef<HTMLFormElement>(null);
  return (
    <form ref={ref} action={formAction} className={className} encType={encType}>
      {state.error && (
        <div role="alert" className="mb-4 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">
          {state.error}
        </div>
      )}
      {state.ok && !state.error && (
        <div role="status" className="mb-4 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
          {state.ok}
        </div>
      )}
      {children}
    </form>
  );
}

/** Confirmation dialog for sensitive actions; optionally collects a reason. Must be rendered inside an <ActionForm>. */
export function ConfirmDialog({
  label,
  title,
  message,
  confirmLabel,
  danger = false,
  withReason = false,
  className = "btn-ghost",
}: {
  label: string;
  title: string;
  message: string;
  confirmLabel: string;
  danger?: boolean;
  withReason?: boolean;
  className?: string;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  return (
    <>
      <button type="button" className={className} onClick={() => ref.current?.showModal()}>
        {label}
      </button>
      <dialog ref={ref} className="m-auto w-[min(92vw,28rem)] rounded-xl p-0 shadow-xl backdrop:bg-navy-950/50">
        <div className="p-5">
          <h2 className="text-lg font-semibold text-navy-900">{title}</h2>
          <p className="mt-2 text-sm text-slate-600">{message}</p>
          {withReason && (
            <div className="mt-4">
              <label className="label" htmlFor={`reason-${label}`}>Reason (required)</label>
              <textarea id={`reason-${label}`} name="reason" required minLength={3} rows={3} className="input" />
            </div>
          )}
          <div className="mt-5 flex justify-end gap-2">
            <button type="button" className="btn-ghost" onClick={() => ref.current?.close()}>Cancel</button>
            <SubmitButton className={danger ? "btn-danger" : "btn-primary"}>{confirmLabel}</SubmitButton>
          </div>
        </div>
      </dialog>
    </>
  );
}
