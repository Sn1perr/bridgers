"use client";

import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

const STATUS_COLORS: Record<string, string> = {
  Active: "#0369a1",
  Pending: "#d97706",
  Approved: "#059669",
  Archived: "#64748b",
  Rejected: "#b91c1c",
};

export function StatusChart({ data }: { data: { status: string; count: number }[] }) {
  if (data.every((d) => d.count === 0)) return <p className="py-10 text-center text-sm text-slate-500">No records yet.</p>;
  return (
    <div role="img" aria-label={`Records by status: ${data.map((d) => `${d.status} ${d.count}`).join(", ")}`} className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="status" tick={{ fontSize: 12 }} />
          <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
          <Tooltip cursor={{ fill: "#f1f5f9" }} />
          <Bar dataKey="count" name="Records" radius={[4, 4, 0, 0]}>
            {data.map((d) => (
              <Cell key={d.status} fill={STATUS_COLORS[d.status] ?? "#12285a"} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function TrendChart({ data }: { data: { label: string; records: number }[] }) {
  if (data.every((d) => d.records === 0)) return <p className="py-10 text-center text-sm text-slate-500">No records created in the last 12 months.</p>;
  return (
    <div role="img" aria-label="Records created per month over the last 12 months" className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 12, left: -16, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="label" tick={{ fontSize: 12 }} />
          <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
          <Tooltip />
          <Line type="monotone" dataKey="records" name="Records created" stroke="#12285a" strokeWidth={2.5} dot={{ r: 3, fill: "#c9a227", stroke: "#12285a" }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function CategoryChart({ data }: { data: { name: string; count: number }[] }) {
  if (data.length === 0) return <p className="py-10 text-center text-sm text-slate-500">No records yet.</p>;
  return (
    <div role="img" aria-label={`Top categories: ${data.map((d) => `${d.name} ${d.count}`).join(", ")}`} className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ top: 8, right: 16, left: 8, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" horizontal={false} />
          <XAxis type="number" allowDecimals={false} tick={{ fontSize: 12 }} />
          <YAxis type="category" dataKey="name" width={120} tick={{ fontSize: 12 }} />
          <Tooltip cursor={{ fill: "#f1f5f9" }} />
          <Bar dataKey="count" name="Records" fill="#c9a227" radius={[0, 4, 4, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
