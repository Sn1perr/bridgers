import fs from "node:fs";
import path from "node:path";
import Link from "next/link";

export function Logo({ light = false, size = 40 }: { light?: boolean; size?: number }) {
  // Drop the official logo at public/logo.png (or logo.svg) and it appears here automatically.
  const file = ["logo.svg", "logo.png"].find((f) => fs.existsSync(path.join(/*turbopackIgnore: true*/ process.cwd(), "public", f)));
  return (
    <div className="flex items-center gap-3">
      {file ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={`/${file}`} alt="Bridgers Resources Limited logo" height={size} style={{ height: size }} />
      ) : (
        <div
          style={{ width: size, height: size }}
          className="flex shrink-0 items-center justify-center rounded-md border-2 border-dashed border-gold-500 text-[9px] font-bold uppercase leading-tight tracking-wider text-gold-500"
          title="Place the official logo at public/logo.png"
        >
          Logo
        </div>
      )}
      <div className="leading-tight">
        <div className={`text-sm font-bold tracking-wide ${light ? "text-white" : "text-navy-900"}`}>BRMS</div>
        <div className={`text-[11px] ${light ? "text-navy-100" : "text-slate-500"}`}>Bridgers Resources Limited</div>
      </div>
    </div>
  );
}

const statusStyles: Record<string, string> = {
  Active: "bg-sky-100 text-sky-800",
  Pending: "bg-amber-100 text-amber-800",
  Approved: "bg-emerald-100 text-emerald-800",
  Archived: "bg-slate-200 text-slate-700",
  Rejected: "bg-red-100 text-red-800",
};
export function StatusBadge({ status }: { status: string }) {
  return <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-semibold ${statusStyles[status] ?? "bg-slate-100"}`}>{status}</span>;
}

const prioStyles: Record<string, string> = {
  Low: "text-slate-500",
  Normal: "text-slate-700",
  High: "text-orange-700 font-semibold",
  Urgent: "text-red-700 font-bold",
};
export function Priority({ value }: { value: string }) {
  return <span className={`text-sm ${prioStyles[value] ?? ""}`}>{value}</span>;
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: React.ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-bold text-navy-900">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-slate-600">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Empty({ title, hint, action }: { title: string; hint?: string; action?: React.ReactNode }) {
  return (
    <div className="rounded-xl border-2 border-dashed border-slate-300 bg-white px-6 py-12 text-center">
      <p className="font-semibold text-navy-900">{title}</p>
      {hint && <p className="mx-auto mt-1 max-w-md text-sm text-slate-600">{hint}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Stat({ label, value, hint, href, tone = "navy" }: { label: string; value: React.ReactNode; hint?: string; href?: string; tone?: "navy" | "gold" | "red" }) {
  const bar = tone === "gold" ? "bg-gold-500" : tone === "red" ? "bg-red-600" : "bg-navy-800";
  const inner = (
    <div className="card relative overflow-hidden transition hover:shadow-md">
      <span className={`absolute inset-y-0 left-0 w-1 ${bar}`} />
      <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">{label}</div>
      <div className="mt-1 text-3xl font-bold text-navy-900">{value}</div>
      {hint && <div className="mt-1 text-xs text-slate-500">{hint}</div>}
    </div>
  );
  return href ? <Link href={href} className="block focus:outline-none focus-visible:ring-2 focus-visible:ring-gold-500 rounded-xl">{inner}</Link> : inner;
}

export const fmtDate = (iso?: string | null) =>
  iso ? new Date(iso).toLocaleDateString("en-NG", { day: "2-digit", month: "short", year: "numeric", timeZone: "Africa/Lagos" }) : "—";
export const fmtDateTime = (iso?: string | null) =>
  iso ? new Date(iso).toLocaleString("en-NG", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", timeZone: "Africa/Lagos" }) : "—";
export const fmtSize = (n: number) => (n < 1024 * 1024 ? `${Math.max(1, Math.round(n / 1024))} KB` : `${(n / 1024 / 1024).toFixed(1)} MB`);
