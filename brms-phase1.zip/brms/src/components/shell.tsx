"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Bell, ChevronsLeft, ChevronsRight, LayoutDashboard, LogOut, Menu, Search, Settings, X, FileText } from "lucide-react";

export type NavItem = { href: string; label: string; icon: "dashboard" | "records" | "notifications" | "settings" };
const icons = { dashboard: LayoutDashboard, records: FileText, notifications: Bell, settings: Settings };

export function Shell({
  nav,
  user,
  unread,
  logo,
  logoutAction,
  children,
}: {
  nav: NavItem[];
  user: { name: string; role: string };
  unread: number;
  logo: React.ReactNode;
  logoutAction: () => Promise<void>;
  children: React.ReactNode;
}) {
  const [collapsed, setCollapsed] = useState(false);
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  const sidebar = (
    <nav aria-label="Main" className="flex h-full flex-col bg-navy-900 text-white">
      <div className="flex h-16 items-center justify-between border-b border-white/10 px-4">
        {!collapsed && logo}
        <button
          className="hidden rounded p-1.5 text-navy-100 hover:bg-white/10 md:block"
          onClick={() => setCollapsed(!collapsed)}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {collapsed ? <ChevronsRight size={18} /> : <ChevronsLeft size={18} />}
        </button>
        <button className="rounded p-1.5 text-navy-100 hover:bg-white/10 md:hidden" onClick={() => setOpen(false)} aria-label="Close menu">
          <X size={20} />
        </button>
      </div>
      <ul className="flex-1 space-y-1 p-3">
        {nav.map((n) => {
          const Icon = icons[n.icon];
          const active = pathname === n.href || pathname.startsWith(n.href + "/");
          return (
            <li key={n.href}>
              <Link
                href={n.href}
                onClick={() => setOpen(false)}
                title={collapsed ? n.label : undefined}
                aria-current={active ? "page" : undefined}
                className={`flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition focus:outline-none focus-visible:ring-2 focus-visible:ring-gold-400 ${
                  active ? "bg-white/10 text-gold-400" : "text-navy-100 hover:bg-white/5 hover:text-white"
                }`}
              >
                <Icon size={18} className="shrink-0" />
                {!collapsed && <span>{n.label}</span>}
                {!collapsed && n.icon === "notifications" && unread > 0 && (
                  <span className="ml-auto rounded-full bg-gold-500 px-2 py-0.5 text-xs font-bold text-navy-950">{unread}</span>
                )}
              </Link>
            </li>
          );
        })}
      </ul>
      <div className="border-t border-white/10 p-3">
        {!collapsed && (
          <div className="mb-2 px-1">
            <div className="truncate text-sm font-semibold">{user.name}</div>
            <div className="text-xs text-navy-100">{user.role}</div>
          </div>
        )}
        <form action={logoutAction}>
          <button className="flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm text-navy-100 hover:bg-white/10" title="Sign out">
            <LogOut size={18} className="shrink-0" />
            {!collapsed && "Sign out"}
          </button>
        </form>
      </div>
    </nav>
  );

  return (
    <div className="min-h-screen">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-2 focus:top-2 focus:z-50 focus:rounded focus:bg-white focus:px-3 focus:py-2">
        Skip to content
      </a>
      <aside className={`fixed inset-y-0 left-0 z-30 hidden transition-all md:block ${collapsed ? "w-[68px]" : "w-64"}`}>{sidebar}</aside>
      {open && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-navy-950/60" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-72">{sidebar}</aside>
        </div>
      )}
      <div className={`transition-all ${collapsed ? "md:pl-[68px]" : "md:pl-64"}`}>
        <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-slate-200 bg-white px-4">
          <button className="rounded p-2 text-navy-900 hover:bg-slate-100 md:hidden" onClick={() => setOpen(true)} aria-label="Open menu">
            <Menu size={22} />
          </button>
          <form action="/search" method="get" role="search" className="relative max-w-xl flex-1">
            <label htmlFor="global-search" className="sr-only">Search records</label>
            <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input id="global-search" name="q" type="search" placeholder="Search records by title, reference or description" className="input pl-9" />
          </form>
          <Link href="/notifications" className="relative rounded p-2 text-navy-900 hover:bg-slate-100" aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`}>
            <Bell size={20} />
            {unread > 0 && <span className="absolute right-1 top-1 h-2.5 w-2.5 rounded-full bg-gold-500 ring-2 ring-white" />}
          </Link>
          <Link href="/account" className="hidden items-center gap-2 rounded-md px-2 py-1 text-sm text-slate-700 hover:bg-slate-100 sm:flex">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-navy-900 text-xs font-bold text-gold-400">
              {user.name.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase()}
            </span>
          </Link>
        </header>
        <main id="main" className="mx-auto max-w-7xl p-4 sm:p-6">{children}</main>
      </div>
    </div>
  );
}
