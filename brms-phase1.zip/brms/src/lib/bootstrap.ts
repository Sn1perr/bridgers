import crypto from "node:crypto";
import { eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { audit } from "./audit";
import { hashPassword, passwordProblems } from "./auth-core";

/** Structural defaults only (no company data). Safe for production; skipped if already present. */
export const DEFAULT_DEPARTMENTS = ["Administration", "Finance & Accounts", "Human Resources", "Operations", "Projects", "Procurement"];
export const DEFAULT_CATEGORIES = ["General", "Correspondence", "Contracts & Agreements", "Financial", "Human Resources", "Project", "Policies & Procedures", "Legal & Compliance"];

export function seedDefaults() {
  for (const name of DEFAULT_DEPARTMENTS) db.insert(schema.departments).values({ name }).onConflictDoNothing().run();
  for (const name of DEFAULT_CATEGORIES) db.insert(schema.categories).values({ name }).onConflictDoNothing().run();
}

export function randomPassword() {
  // Guaranteed to satisfy the password policy.
  const body = crypto.randomBytes(12).toString("base64url");
  return `${body}aA1!`;
}

export function createUser(opts: {
  email: string;
  name: string;
  role: string;
  password: string;
  departmentName?: string;
  mustChangePassword?: boolean;
}) {
  const problems = passwordProblems(opts.password);
  if (problems.length) throw new Error(`Password needs ${problems.join(", ")}.`);
  const dep = opts.departmentName
    ? db.select().from(schema.departments).where(eq(schema.departments.name, opts.departmentName)).get()
    : undefined;
  return db
    .insert(schema.users)
    .values({
      email: opts.email.trim().toLowerCase(),
      name: opts.name.trim(),
      role: opts.role,
      passwordHash: hashPassword(opts.password),
      departmentId: dep?.id ?? null,
      mustChangePassword: opts.mustChangePassword ?? true,
    })
    .returning()
    .get();
}

export function seedAdmin() {
  const email = (process.env.BRMS_ADMIN_EMAIL ?? "").trim().toLowerCase();
  if (!email) throw new Error("Set BRMS_ADMIN_EMAIL before seeding.");
  if (db.select().from(schema.users).where(eq(schema.users.email, email)).get()) return null;
  const password = process.env.BRMS_ADMIN_PASSWORD || randomPassword();
  const u = createUser({
    email,
    name: process.env.BRMS_ADMIN_NAME ?? "System Administrator",
    role: "super_admin",
    password,
    departmentName: "Administration",
    mustChangePassword: true,
  });
  audit(null, "user.created", "user", u.id, { role: "super_admin", via: "seed" }, "system");
  return { email, password, generated: !process.env.BRMS_ADMIN_PASSWORD };
}
