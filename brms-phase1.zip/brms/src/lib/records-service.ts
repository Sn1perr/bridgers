import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { and, asc, desc, eq, gte, isNull, like, lte, ne, or, sql, type SQL } from "drizzle-orm";
import { alias } from "drizzle-orm/sqlite-core";
import { db, schema, UPLOAD_DIR } from "@/db";
import { audit } from "./audit";
import { can, type SessionUser } from "./auth-core";
import { RECORD_PRIORITIES, RECORD_STATUSES, type Permission } from "./permissions";

const { records, categories, departments, users, recordNotes, attachments, auditLogs, counters } = schema;

export class ServiceError extends Error {}

function need(user: SessionUser, p: Permission) {
  if (!can(user, p)) throw new ServiceError("You do not have permission to do that.");
}

/** Records a user may see: everything if they hold records.view_all, otherwise own department or own records. */
function visibleCondition(user: SessionUser): SQL {
  const notDeleted = isNull(records.deletedAt);
  if (can(user, "records.view_all")) return notDeleted;
  const mine = user.departmentId
    ? or(eq(records.departmentId, user.departmentId), eq(records.createdBy, user.id))!
    : eq(records.createdBy, user.id);
  return and(notDeleted, mine)!;
}

export type RecordInput = {
  title: string;
  description?: string;
  categoryId: number;
  departmentId: number;
  priority?: string;
  status?: string;
};

function clean(input: RecordInput) {
  const title = (input.title ?? "").trim();
  if (title.length < 3) throw new ServiceError("Title is required (at least 3 characters).");
  if (title.length > 200) throw new ServiceError("Title is too long (200 characters maximum).");
  const description = (input.description ?? "").trim().slice(0, 10_000);
  const priority = input.priority ?? "Normal";
  if (!(RECORD_PRIORITIES as readonly string[]).includes(priority)) throw new ServiceError("Invalid priority.");
  const cat = db.select().from(categories).where(eq(categories.id, input.categoryId)).get();
  if (!cat || !cat.active) throw new ServiceError("Choose a valid category.");
  const dep = db.select().from(departments).where(eq(departments.id, input.departmentId)).get();
  if (!dep) throw new ServiceError("Choose a valid department.");
  return { title, description, priority, categoryId: cat.id, departmentId: dep.id };
}

function nextRefNo(): string {
  const year = new Date().getFullYear();
  const key = `record-${year}`;
  const row = db.select().from(counters).where(eq(counters.key, key)).get();
  const n = (row?.value ?? 0) + 1;
  if (row) db.update(counters).set({ value: n }).where(eq(counters.key, key)).run();
  else db.insert(counters).values({ key, value: n }).run();
  return `BR-REC-${year}-${String(n).padStart(4, "0")}`;
}

export function createRecord(user: SessionUser, input: RecordInput, opts: { allowDuplicate?: boolean; demo?: boolean } = {}) {
  need(user, "records.create");
  const v = clean(input);
  if (input.status && !["Active", "Pending"].includes(input.status))
    throw new ServiceError("New records can only start as Active or Pending; approval is a separate step.");
  if (!can(user, "records.view_all") && user.departmentId && v.departmentId !== user.departmentId)
    throw new ServiceError("You can only create records for your own department.");
  if (!opts.allowDuplicate) {
    const dup = db
      .select({ refNo: records.refNo })
      .from(records)
      .where(and(isNull(records.deletedAt), eq(records.categoryId, v.categoryId), sql`lower(${records.title}) = lower(${v.title})`))
      .get();
    if (dup) throw new ServiceError(`A record with this title already exists in that category (${dup.refNo}). Tick "create anyway" if this is intentional.`);
  }
  return db.transaction((tx) => {
    void tx;
    const refNo = nextRefNo();
    const row = db
      .insert(records)
      .values({ ...v, refNo, status: input.status ?? "Pending", createdBy: user.id, updatedBy: user.id, isDemo: !!opts.demo })
      .returning()
      .get();
    audit(user, "record.created", "record", row.id, { refNo, title: v.title });
    return row;
  });
}

function getVisible(user: SessionUser, id: number) {
  const r = db.select().from(records).where(and(eq(records.id, id), visibleCondition(user))).get();
  if (!r) throw new ServiceError("Record not found.");
  return r;
}

function canModify(user: SessionUser, r: typeof records.$inferSelect) {
  return can(user, "records.edit") && (can(user, "records.view_all") || r.createdBy === user.id);
}

export function updateRecord(user: SessionUser, id: number, input: RecordInput) {
  const r = getVisible(user, id);
  if (!canModify(user, r)) throw new ServiceError("You do not have permission to edit this record.");
  if (r.status === "Approved") throw new ServiceError("Approved records are locked. An approver must reopen it before it can be edited.");
  if (r.status === "Archived") throw new ServiceError("Archived records are read-only. Restore it first.");
  const v = clean(input);
  if (!can(user, "records.view_all") && user.departmentId && v.departmentId !== user.departmentId)
    throw new ServiceError("You can only assign records to your own department.");
  const changes: Record<string, [unknown, unknown]> = {};
  for (const k of ["title", "description", "priority", "categoryId", "departmentId"] as const)
    if (r[k] !== v[k]) changes[k] = [r[k], v[k]];
  let status = r.status;
  if (input.status && input.status !== r.status) {
    if (!["Active", "Pending"].includes(input.status) || !["Active", "Pending", "Rejected"].includes(r.status))
      throw new ServiceError("Use the approval and archive actions to change to that status.");
    status = input.status;
    changes.status = [r.status, status];
  }
  if (Object.keys(changes).length === 0) return r;
  const row = db
    .update(records)
    .set({ ...v, status, updatedBy: user.id, updatedAt: new Date().toISOString() })
    .where(eq(records.id, id))
    .returning()
    .get();
  audit(user, "record.updated", "record", id, changes);
  return row;
}

export function decide(user: SessionUser, id: number, decision: "Approved" | "Rejected", reason?: string) {
  need(user, "records.approve");
  const r = getVisible(user, id);
  if (r.status !== "Pending") throw new ServiceError("Only records awaiting approval (Pending) can be approved or rejected.");
  if (r.createdBy === user.id) throw new ServiceError("You cannot approve or reject a record you created. Another approver must do it.");
  const why = (reason ?? "").trim();
  if (decision === "Rejected" && why.length < 3) throw new ServiceError("Please give a reason for rejecting.");
  const now = new Date().toISOString();
  db.update(records)
    .set({ status: decision, approvedBy: decision === "Approved" ? user.id : null, approvedAt: decision === "Approved" ? now : null, updatedBy: user.id, updatedAt: now })
    .where(eq(records.id, id))
    .run();
  if (why) db.insert(recordNotes).values({ recordId: id, authorId: user.id, body: `${decision}: ${why}` }).run();
  audit(user, decision === "Approved" ? "record.approved" : "record.rejected", "record", id, { reason: why || undefined });
  db.insert(schema.notifications)
    .values({ userId: r.createdBy, title: `${r.refNo} was ${decision.toLowerCase()}`, body: r.title, href: `/records/${id}` })
    .run();
}

export function reopen(user: SessionUser, id: number, reason: string) {
  need(user, "records.approve");
  const r = getVisible(user, id);
  if (!["Approved", "Rejected"].includes(r.status)) throw new ServiceError("Only approved or rejected records can be reopened.");
  if (reason.trim().length < 3) throw new ServiceError("Please give a reason for reopening.");
  db.update(records)
    .set({ status: "Pending", approvedBy: null, approvedAt: null, updatedBy: user.id, updatedAt: new Date().toISOString() })
    .where(eq(records.id, id))
    .run();
  db.insert(recordNotes).values({ recordId: id, authorId: user.id, body: `Reopened: ${reason.trim()}` }).run();
  audit(user, "record.reopened", "record", id, { from: r.status, reason: reason.trim() });
}

export function archiveRecord(user: SessionUser, id: number) {
  need(user, "records.archive");
  const r = getVisible(user, id);
  if (r.status === "Archived") throw new ServiceError("Record is already archived.");
  db.update(records).set({ status: "Archived", updatedBy: user.id, updatedAt: new Date().toISOString() }).where(eq(records.id, id)).run();
  audit(user, "record.archived", "record", id, { from: r.status });
}

export function restoreRecord(user: SessionUser, id: number) {
  need(user, "records.archive");
  const r = getVisible(user, id);
  if (r.status !== "Archived") throw new ServiceError("Only archived records can be restored.");
  const last = db
    .select()
    .from(auditLogs)
    .where(and(eq(auditLogs.entity, "record"), eq(auditLogs.entityId, String(id)), eq(auditLogs.action, "record.archived")))
    .orderBy(desc(auditLogs.id))
    .get();
  let prev = "Active";
  try {
    const f = JSON.parse(last?.detail ?? "{}").from;
    if (f && f !== "Archived") prev = f;
  } catch {}
  db.update(records).set({ status: prev, updatedBy: user.id, updatedAt: new Date().toISOString() }).where(eq(records.id, id)).run();
  audit(user, "record.restored", "record", id, { to: prev });
}

/** Soft delete: the row stays in the database and in the audit trail but disappears from every list. */
export function deleteRecord(user: SessionUser, id: number, reason: string) {
  need(user, "records.archive");
  const r = getVisible(user, id);
  if (r.status === "Approved") throw new ServiceError("Approved records cannot be deleted. Archive them instead.");
  if (reason.trim().length < 3) throw new ServiceError("Please give a reason for deleting.");
  db.update(records).set({ deletedAt: new Date().toISOString(), updatedBy: user.id }).where(eq(records.id, id)).run();
  audit(user, "record.deleted", "record", id, { refNo: r.refNo, reason: reason.trim() });
}

export function addNote(user: SessionUser, id: number, body: string) {
  getVisible(user, id);
  need(user, "records.view");
  const text = body.trim();
  if (!text) throw new ServiceError("Note cannot be empty.");
  db.insert(recordNotes).values({ recordId: id, authorId: user.id, body: text.slice(0, 5000) }).run();
  audit(user, "record.note_added", "record", id);
}

export type RecordFilters = {
  q?: string;
  categoryId?: number;
  departmentId?: number;
  status?: string;
  createdBy?: number;
  from?: string;
  to?: string;
  sort?: string;
  dir?: "asc" | "desc";
  page?: number;
  pageSize?: number;
};

const esc = (s: string) => s.replace(/[\\%_]/g, (c) => `\\${c}`);

export function listRecords(user: SessionUser, f: RecordFilters = {}) {
  need(user, "records.view");
  const creator = alias(users, "creator");
  const conds: SQL[] = [visibleCondition(user)];
  if (f.q?.trim()) {
    const t = `%${esc(f.q.trim())}%`;
    conds.push(or(sql`${records.title} LIKE ${t} ESCAPE '\\'`, sql`${records.refNo} LIKE ${t} ESCAPE '\\'`, sql`${records.description} LIKE ${t} ESCAPE '\\'`)!);
  }
  if (f.categoryId) conds.push(eq(records.categoryId, f.categoryId));
  if (f.departmentId) conds.push(eq(records.departmentId, f.departmentId));
  if (f.createdBy) conds.push(eq(records.createdBy, f.createdBy));
  if (f.status && (RECORD_STATUSES as readonly string[]).includes(f.status)) conds.push(eq(records.status, f.status));
  else conds.push(ne(records.status, "Archived"));
  if (f.from) conds.push(gte(sql`substr(${records.createdAt},1,10)`, f.from));
  if (f.to) conds.push(lte(sql`substr(${records.createdAt},1,10)`, f.to));
  const where = and(...conds);
  const pageSize = Math.min(Math.max(f.pageSize ?? 15, 1), 100);
  const page = Math.max(f.page ?? 1, 1);
  const sortCols = { refNo: records.refNo, title: records.title, status: records.status, priority: records.priority, createdAt: records.createdAt, updatedAt: records.updatedAt } as const;
  const col = sortCols[(f.sort as keyof typeof sortCols) ?? "updatedAt"] ?? records.updatedAt;
  const order = f.dir === "asc" ? asc(col) : desc(col);
  const total = db.select({ n: sql<number>`count(*)` }).from(records).where(where).get()!.n;
  const rows = db
    .select({
      id: records.id,
      refNo: records.refNo,
      title: records.title,
      status: records.status,
      priority: records.priority,
      createdAt: records.createdAt,
      updatedAt: records.updatedAt,
      category: categories.name,
      department: departments.name,
      creator: creator.name,
      isDemo: records.isDemo,
    })
    .from(records)
    .innerJoin(categories, eq(categories.id, records.categoryId))
    .innerJoin(departments, eq(departments.id, records.departmentId))
    .innerJoin(creator, eq(creator.id, records.createdBy))
    .where(where)
    .orderBy(order, desc(records.id))
    .limit(pageSize)
    .offset((page - 1) * pageSize)
    .all();
  return { rows, total, page, pageSize, pages: Math.max(1, Math.ceil(total / pageSize)) };
}

export function getRecordDetail(user: SessionUser, id: number) {
  need(user, "records.view");
  const r = getVisible(user, id);
  const creator = alias(users, "creator");
  const updater = alias(users, "updater");
  const approver = alias(users, "approver");
  const full = db
    .select({
      r: records,
      category: categories.name,
      department: departments.name,
      creator: creator.name,
      updater: updater.name,
      approver: approver.name,
    })
    .from(records)
    .innerJoin(categories, eq(categories.id, records.categoryId))
    .innerJoin(departments, eq(departments.id, records.departmentId))
    .innerJoin(creator, eq(creator.id, records.createdBy))
    .innerJoin(updater, eq(updater.id, records.updatedBy))
    .leftJoin(approver, eq(approver.id, records.approvedBy))
    .where(eq(records.id, r.id))
    .get()!;
  const notes = db
    .select({ id: recordNotes.id, body: recordNotes.body, createdAt: recordNotes.createdAt, author: users.name })
    .from(recordNotes)
    .innerJoin(users, eq(users.id, recordNotes.authorId))
    .where(eq(recordNotes.recordId, id))
    .orderBy(desc(recordNotes.id))
    .all();
  const files = can(user, "attachments.download") || can(user, "attachments.upload")
    ? db
        .select({ id: attachments.id, name: attachments.originalName, size: attachments.size, mimeType: attachments.mimeType, createdAt: attachments.createdAt, by: users.name })
        .from(attachments)
        .innerJoin(users, eq(users.id, attachments.uploadedBy))
        .where(and(eq(attachments.recordId, id), isNull(attachments.deletedAt)))
        .orderBy(desc(attachments.id))
        .all()
    : [];
  const history = db
    .select()
    .from(auditLogs)
    .where(and(eq(auditLogs.entity, "record"), eq(auditLogs.entityId, String(id))))
    .orderBy(desc(auditLogs.id))
    .all();
  return {
    ...full,
    notes,
    files,
    history,
    can: {
      edit: canModify(user, r) && !["Approved", "Archived"].includes(r.status),
      approve: can(user, "records.approve") && r.status === "Pending" && r.createdBy !== user.id,
      reopen: can(user, "records.approve") && ["Approved", "Rejected"].includes(r.status),
      archive: can(user, "records.archive") && r.status !== "Archived",
      restore: can(user, "records.archive") && r.status === "Archived",
      remove: can(user, "records.archive") && r.status !== "Approved",
      upload: can(user, "attachments.upload") && canModify(user, r) && !["Approved", "Archived"].includes(r.status),
      download: can(user, "attachments.download"),
    },
  };
}

/* ----------------------------- attachments ----------------------------- */

const MAX_UPLOAD = 10 * 1024 * 1024;
const TYPES: Record<string, { mime: string; magic: number[] }> = {
  pdf: { mime: "application/pdf", magic: [0x25, 0x50, 0x44, 0x46] },
  docx: { mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", magic: [0x50, 0x4b, 0x03, 0x04] },
  xlsx: { mime: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", magic: [0x50, 0x4b, 0x03, 0x04] },
  jpg: { mime: "image/jpeg", magic: [0xff, 0xd8, 0xff] },
  jpeg: { mime: "image/jpeg", magic: [0xff, 0xd8, 0xff] },
  png: { mime: "image/png", magic: [0x89, 0x50, 0x4e, 0x47] },
};

export function addAttachment(user: SessionUser, recordId: number, originalName: string, data: Buffer) {
  need(user, "attachments.upload");
  const r = getVisible(user, recordId);
  if (!canModify(user, r)) throw new ServiceError("You do not have permission to add files to this record.");
  if (["Approved", "Archived"].includes(r.status)) throw new ServiceError("This record is locked; files cannot be added.");
  if (data.length === 0) throw new ServiceError("The file is empty.");
  if (data.length > MAX_UPLOAD) throw new ServiceError("File is too large (10 MB maximum).");
  const safeName = path.basename(originalName).replace(/[^\w.\- ()]/g, "_").slice(0, 120) || "file";
  const ext = safeName.split(".").pop()?.toLowerCase() ?? "";
  const type = TYPES[ext];
  if (!type) throw new ServiceError("Only PDF, DOCX, XLSX, JPG and PNG files are allowed.");
  if (!type.magic.every((b, i) => data[i] === b)) throw new ServiceError("The file contents do not match its type.");
  const storedName = crypto.randomUUID();
  fs.writeFileSync(path.join(UPLOAD_DIR, storedName), data, { mode: 0o600 });
  const sha256 = crypto.createHash("sha256").update(data).digest("hex");
  const row = db
    .insert(attachments)
    .values({ recordId, originalName: safeName, storedName, mimeType: type.mime, size: data.length, sha256, uploadedBy: user.id })
    .returning()
    .get();
  db.update(records).set({ updatedAt: new Date().toISOString(), updatedBy: user.id }).where(eq(records.id, recordId)).run();
  audit(user, "attachment.uploaded", "record", recordId, { file: safeName, size: data.length, sha256 });
  return row;
}

export function openAttachment(user: SessionUser, attachmentId: number) {
  need(user, "attachments.download");
  const a = db.select().from(attachments).where(and(eq(attachments.id, attachmentId), isNull(attachments.deletedAt))).get();
  if (!a) throw new ServiceError("File not found.");
  getVisible(user, a.recordId); // same visibility rules as the record itself
  const file = path.join(UPLOAD_DIR, a.storedName);
  if (!fs.existsSync(file)) throw new ServiceError("File is missing from storage. Contact the administrator.");
  audit(user, "attachment.downloaded", "record", a.recordId, { file: a.originalName });
  return { name: a.originalName, mime: a.mimeType, data: fs.readFileSync(file) };
}

export function removeAttachment(user: SessionUser, attachmentId: number) {
  const a = db.select().from(attachments).where(and(eq(attachments.id, attachmentId), isNull(attachments.deletedAt))).get();
  if (!a) throw new ServiceError("File not found.");
  const r = getVisible(user, a.recordId);
  need(user, "attachments.upload");
  if (!canModify(user, r) || ["Approved", "Archived"].includes(r.status)) throw new ServiceError("This record is locked or you lack permission.");
  // Soft delete only: the stored file is kept for audit and recovery.
  db.update(attachments).set({ deletedAt: new Date().toISOString() }).where(eq(attachments.id, attachmentId)).run();
  audit(user, "attachment.removed", "record", a.recordId, { file: a.originalName });
}

/* ----------------------------- categories ------------------------------ */

export function createCategory(user: SessionUser, name: string) {
  need(user, "categories.manage");
  const n = name.trim();
  if (n.length < 2 || n.length > 60) throw new ServiceError("Category name must be 2 to 60 characters.");
  const exists = db.select().from(categories).where(sql`lower(${categories.name}) = lower(${n})`).get();
  if (exists) throw new ServiceError("That category already exists.");
  const row = db.insert(categories).values({ name: n }).returning().get();
  audit(user, "category.created", "category", row.id, { name: n });
  return row;
}

export function setCategoryActive(user: SessionUser, id: number, active: boolean) {
  need(user, "categories.manage");
  db.update(categories).set({ active }).where(eq(categories.id, id)).run();
  audit(user, active ? "category.enabled" : "category.disabled", "category", id);
}

/* ------------------------------ lookups -------------------------------- */

export const listCategories = (onlyActive = true) =>
  db.select().from(categories).where(onlyActive ? eq(categories.active, true) : undefined).orderBy(asc(categories.name)).all();
export const listDepartments = () => db.select().from(departments).orderBy(asc(departments.name)).all();
export const listPeople = () =>
  db.select({ id: users.id, name: users.name }).from(users).where(eq(users.active, true)).orderBy(asc(users.name)).all();
export { like };
export { visibleCondition };
