export const PERMISSIONS = {
  "dashboard.view": "View the dashboard",
  "records.view": "View records (own department and own records)",
  "records.view_all": "View records of all departments",
  "records.create": "Create records",
  "records.edit": "Edit records",
  "records.archive": "Archive and restore records",
  "records.approve": "Approve or reject records",
  "attachments.upload": "Upload attachments",
  "attachments.download": "Download attachments",
  "categories.manage": "Manage record categories",
  "users.manage": "Manage user accounts",
  "roles.manage": "Configure role permissions",
  "audit.view": "View audit log",
} as const;

export type Permission = keyof typeof PERMISSIONS;
export const ALL_PERMISSIONS = Object.keys(PERMISSIONS) as Permission[];

export const ROLES = {
  super_admin: "Super Administrator",
  managing_director: "Managing Director",
  records_officer: "Records Officer",
  accountant: "Accountant",
  hr_officer: "HR Officer",
  project_manager: "Project Manager",
  staff: "Departmental Staff",
} as const;

export type Role = keyof typeof ROLES;
export const ROLE_KEYS = Object.keys(ROLES) as Role[];

const staffBase: Permission[] = [
  "dashboard.view",
  "records.view",
  "records.create",
  "records.edit",
  "attachments.upload",
  "attachments.download",
];

/** Defaults written to the database on first run; admins can change them in Settings. */
export const DEFAULT_ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  super_admin: ALL_PERMISSIONS,
  managing_director: [
    "dashboard.view",
    "records.view",
    "records.view_all",
    "records.approve",
    "attachments.download",
    "audit.view",
  ],
  records_officer: [
    ...staffBase,
    "records.view_all",
    "records.archive",
    "categories.manage",
  ],
  accountant: staffBase,
  hr_officer: staffBase,
  project_manager: staffBase,
  staff: staffBase,
};

export const RECORD_STATUSES = ["Active", "Pending", "Approved", "Archived", "Rejected"] as const;
export const RECORD_PRIORITIES = ["Low", "Normal", "High", "Urgent"] as const;
export type RecordStatus = (typeof RECORD_STATUSES)[number];
