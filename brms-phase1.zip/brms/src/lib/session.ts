import { cache } from "react";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { loadSession, logout, type SessionUser } from "./auth-core";
import type { Permission } from "./permissions";

export const COOKIE = "brms_session";

export async function clientIp() {
  const h = await headers();
  return h.get("x-forwarded-for")?.split(",")[0]?.trim() ?? h.get("x-real-ip") ?? null;
}

export async function setSessionCookie(token: string) {
  (await cookies()).set(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    // No maxAge: a browser-session cookie. Server-side idle/absolute timeouts still apply.
  });
}

export async function clearSession(user?: SessionUser | null) {
  const c = await cookies();
  logout(c.get(COOKIE)?.value, user);
  c.delete(COOKIE);
}

export const getUser = cache(async (): Promise<SessionUser | null> => {
  const token = (await cookies()).get(COOKIE)?.value;
  return loadSession(token, await clientIp());
});

export async function requireUser(opts: { allowMustChange?: boolean } = {}) {
  const user = await getUser();
  if (!user) redirect("/login");
  if (user.mustChangePassword && !opts.allowMustChange) redirect("/change-password");
  return user;
}

export async function requirePermission(p: Permission) {
  const user = await requireUser();
  if (!user.permissions.has(p)) redirect("/dashboard?denied=1");
  return user;
}
