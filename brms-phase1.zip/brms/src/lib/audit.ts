import { db, schema } from "@/db";

export type Actor = { id: number; email: string; ip?: string | null };

export function audit(
  actor: Actor | null,
  action: string,
  entity: string,
  entityId: string | number | null,
  detail?: unknown,
  emailOverride?: string,
) {
  db.insert(schema.auditLogs)
    .values({
      userId: actor?.id ?? null,
      userEmail: actor?.email ?? emailOverride ?? null,
      action,
      entity,
      entityId: entityId == null ? null : String(entityId),
      detail: detail === undefined ? null : JSON.stringify(detail),
      ip: actor?.ip ?? null,
    })
    .run();
}
