import { and, asc, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { audit } from "./audit";
import { can, changePassword, passwordProblems, revokeUserSessions, type SessionUser } from "./auth-core";
import { createUser } from "./bootstrap";
import { ALL_PERMISSIONS, ROLE_KEYS, type Permission } from "./permissions";
import { ServiceError } from "./records-service";

const need = (u: SessionUser, p: Permission) => {
  if (!can(u, p)) throw new ServiceError("You do not have permission to do that.");
};

export function listUsers() {
  return db
    .select({
      id: schema.users.id, name: schema.users.name, email: schema.users.email, role: schema.users.role,
      active: schema.users.active, lastLoginAt: schema.users.lastLoginAt, department: schema.departments.name,
    })
    .from(schema.users)
    .leftJoin(schema.departments, eq(schema.departments.id, schema.users.departmentId))
    .orderBy(asc(schema.users.name))
    .all();
}

function activeSuperAdmins() {
  return db.select().from(schema.users).where(and(eq(schema.users.role, "super_admin"), eq(schema.users.active, true))).all();
}

export function adminCreateUser(actor: SessionUser, i: { name: string; email: string; role: string; departmentId: number; password: string }) {
  need(actor, "users.manage");
  if (!ROLE_KEYS.includes(i.role as never)) throw new ServiceError("Choose a valid role.");
  if (i.role === "super_admin" && actor.role !== "super_admin") throw new ServiceError("Only a Super Administrator can create another Super Administrator.");
  if (i.name.trim().length < 2) throw new ServiceError("Enter the person's full name.");
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(i.email.trim())) throw new ServiceError("Enter a valid email address.");
  const problems = passwordProblems(i.password);
  if (problems.length) throw new ServiceError(`Temporary password needs ${problems.join(", ")}.`);
  const dep = db.select().from(schema.departments).where(eq(schema.departments.id, i.departmentId)).get();
  if (!dep) throw new ServiceError("Choose a department.");
  if (db.select().from(schema.users).where(eq(schema.users.email, i.email.trim().toLowerCase())).get())
    throw new ServiceError("A user with that email already exists.");
  const u = createUser({ email: i.email, name: i.name, role: i.role, password: i.password, departmentName: dep.name, mustChangePassword: true });
  audit(actor, "user.created", "user", u.id, { email: u.email, role: u.role });
  return u;
}

export function adminUpdateUser(actor: SessionUser, id: number, i: { role: string; departmentId: number }) {
  need(actor, "users.manage");
  const u = db.select().from(schema.users).where(eq(schema.users.id, id)).get();
  if (!u) throw new ServiceError("User not found.");
  if (!ROLE_KEYS.includes(i.role as never)) throw new ServiceError("Choose a valid role.");
  if ((i.role === "super_admin" || u.role === "super_admin") && actor.role !== "super_admin")
    throw new ServiceError("Only a Super Administrator can change Super Administrator roles.");
  if (u.role === "super_admin" && i.role !== "super_admin" && activeSuperAdmins().length <= 1)
    throw new ServiceError("There must always be at least one active Super Administrator.");
  db.update(schema.users).set({ role: i.role, departmentId: i.departmentId }).where(eq(schema.users.id, id)).run();
  revokeUserSessions(id);
  audit(actor, "user.updated", "user", id, { role: [u.role, i.role], departmentId: [u.departmentId, i.departmentId] });
}

export function adminSetActive(actor: SessionUser, id: number, active: boolean) {
  need(actor, "users.manage");
  const u = db.select().from(schema.users).where(eq(schema.users.id, id)).get();
  if (!u) throw new ServiceError("User not found.");
  if (id === actor.id) throw new ServiceError("You cannot deactivate your own account.");
  if (u.role === "super_admin" && actor.role !== "super_admin") throw new ServiceError("Only a Super Administrator can do that.");
  if (!active && u.role === "super_admin" && activeSuperAdmins().length <= 1)
    throw new ServiceError("There must always be at least one active Super Administrator.");
  db.update(schema.users).set({ active }).where(eq(schema.users.id, id)).run();
  if (!active) revokeUserSessions(id);
  audit(actor, active ? "user.activated" : "user.deactivated", "user", id);
}

export function adminResetPassword(actor: SessionUser, id: number, tempPassword: string) {
  need(actor, "users.manage");
  const u = db.select().from(schema.users).where(eq(schema.users.id, id)).get();
  if (!u) throw new ServiceError("User not found.");
  if (u.role === "super_admin" && actor.role !== "super_admin") throw new ServiceError("Only a Super Administrator can do that.");
  const res = changePassword(id, null, tempPassword, actor);
  if (!res.ok) throw new ServiceError(res.error);
  db.update(schema.users).set({ mustChangePassword: true }).where(eq(schema.users.id, id)).run();
}

export function getRoleMatrix() {
  const rows = db.select().from(schema.rolePermissions).all();
  const m = new Map<string, Set<string>>();
  for (const r of rows) (m.get(r.role) ?? m.set(r.role, new Set()).get(r.role)!).add(r.permission);
  return m;
}

export function setRolePermissions(actor: SessionUser, role: string, perms: string[]) {
  need(actor, "roles.manage");
  if (!ROLE_KEYS.includes(role as never)) throw new ServiceError("Unknown role.");
  if (role === "super_admin") throw new ServiceError("The Super Administrator role always has every permission.");
  const valid = perms.filter((p): p is Permission => (ALL_PERMISSIONS as string[]).includes(p));
  const before = [...(getRoleMatrix().get(role) ?? [])].sort();
  db.transaction(() => {
    db.delete(schema.rolePermissions).where(eq(schema.rolePermissions.role, role)).run();
    for (const p of valid) db.insert(schema.rolePermissions).values({ role, permission: p }).run();
  });
  const after: string[] = [...valid].sort();
  audit(actor, "role.permissions_changed", "role", role, {
    added: after.filter((p) => !before.includes(p)),
    removed: before.filter((p) => !after.includes(p)),
  });
}
