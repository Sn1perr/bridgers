import bcrypt from "bcryptjs";
import crypto from "node:crypto";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/db";
import { audit } from "./audit";
import type { Permission, Role } from "./permissions";

export const IDLE_MS = Number(process.env.BRMS_IDLE_MINUTES ?? 30) * 60_000;
export const MAX_SESSION_MS = Number(process.env.BRMS_MAX_SESSION_HOURS ?? 12) * 3_600_000;
const MAX_FAILED = 5;
const LOCK_MS = 15 * 60_000;

export function passwordProblems(pw: string): string[] {
  const p: string[] = [];
  if (pw.length < 10) p.push("at least 10 characters");
  if (!/[a-z]/.test(pw)) p.push("a lowercase letter");
  if (!/[A-Z]/.test(pw)) p.push("an uppercase letter");
  if (!/[0-9]/.test(pw)) p.push("a number");
  if (!/[^A-Za-z0-9]/.test(pw)) p.push("a symbol");
  return p;
}

export const hashPassword = (pw: string) => bcrypt.hashSync(pw, 12);
const sha = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
// Compared against when the email is unknown so response time doesn't reveal valid accounts.
const DUMMY_HASH = bcrypt.hashSync("not-a-real-password", 12);

export type SessionUser = {
  id: number;
  email: string;
  name: string;
  role: Role;
  departmentId: number | null;
  mustChangePassword: boolean;
  permissions: Set<Permission>;
  ip?: string | null;
};

export function loginWithPassword(
  email: string,
  password: string,
  ip?: string | null,
): { ok: true; token: string; user: { id: number; mustChangePassword: boolean } } | { ok: false; error: string } {
  const generic = { ok: false as const, error: "Invalid email or password." };
  const e = email.trim().toLowerCase();
  const user = db.select().from(schema.users).where(eq(schema.users.email, e)).get();
  if (!user) {
    bcrypt.compareSync(password, DUMMY_HASH);
    audit({ id: 0, email: e, ip }, "login.failed", "user", null, { reason: "unknown email" });
    return generic;
  }
  if (user.lockedUntil && new Date(user.lockedUntil) > new Date()) {
    audit({ id: user.id, email: e, ip }, "login.blocked", "user", user.id, { reason: "locked" });
    return { ok: false, error: "Account temporarily locked after repeated failed attempts. Try again in 15 minutes." };
  }
  const good = bcrypt.compareSync(password, user.passwordHash);
  if (!good || !user.active) {
    const attempts = user.failedAttempts + 1;
    const lock = attempts >= MAX_FAILED ? new Date(Date.now() + LOCK_MS).toISOString() : null;
    db.update(schema.users)
      .set({ failedAttempts: lock ? 0 : attempts, lockedUntil: lock })
      .where(eq(schema.users.id, user.id))
      .run();
    audit({ id: user.id, email: e, ip }, lock ? "login.locked" : "login.failed", "user", user.id);
    return generic;
  }
  const token = crypto.randomBytes(32).toString("base64url");
  const nowIso = new Date().toISOString();
  db.insert(schema.sessions)
    .values({ id: sha(token), userId: user.id, createdAt: nowIso, lastSeenAt: nowIso, ip: ip ?? null })
    .run();
  db.update(schema.users)
    .set({ failedAttempts: 0, lockedUntil: null, lastLoginAt: nowIso })
    .where(eq(schema.users.id, user.id))
    .run();
  audit({ id: user.id, email: user.email, ip }, "login.success", "user", user.id);
  return { ok: true, token, user: { id: user.id, mustChangePassword: user.mustChangePassword } };
}

export function loadSession(token: string | undefined, ip?: string | null): SessionUser | null {
  if (!token) return null;
  const s = db.select().from(schema.sessions).where(eq(schema.sessions.id, sha(token))).get();
  if (!s) return null;
  const now = Date.now();
  if (now - Date.parse(s.lastSeenAt) > IDLE_MS || now - Date.parse(s.createdAt) > MAX_SESSION_MS) {
    db.delete(schema.sessions).where(eq(schema.sessions.id, s.id)).run();
    return null;
  }
  const u = db.select().from(schema.users).where(eq(schema.users.id, s.userId)).get();
  if (!u || !u.active) {
    db.delete(schema.sessions).where(eq(schema.sessions.id, s.id)).run();
    return null;
  }
  // Slide the idle window (at most once a minute to avoid a write on every request).
  if (now - Date.parse(s.lastSeenAt) > 60_000) {
    db.update(schema.sessions).set({ lastSeenAt: new Date(now).toISOString() }).where(eq(schema.sessions.id, s.id)).run();
  }
  const perms = db.select().from(schema.rolePermissions).where(eq(schema.rolePermissions.role, u.role)).all();
  return {
    id: u.id,
    email: u.email,
    name: u.name,
    role: u.role as Role,
    departmentId: u.departmentId,
    mustChangePassword: u.mustChangePassword,
    permissions: new Set(perms.map((p) => p.permission as Permission)),
    ip,
  };
}

export function logout(token: string | undefined, user?: SessionUser | null) {
  if (token) db.delete(schema.sessions).where(eq(schema.sessions.id, sha(token))).run();
  if (user) audit(user, "logout", "user", user.id);
}

export function revokeUserSessions(userId: number) {
  db.delete(schema.sessions).where(eq(schema.sessions.userId, userId)).run();
}

export function changePassword(userId: number, current: string | null, next: string, actor: SessionUser | null) {
  const problems = passwordProblems(next);
  if (problems.length) return { ok: false as const, error: `Password needs ${problems.join(", ")}.` };
  const u = db.select().from(schema.users).where(eq(schema.users.id, userId)).get();
  if (!u) return { ok: false as const, error: "User not found." };
  if (current !== null && !bcrypt.compareSync(current, u.passwordHash))
    return { ok: false as const, error: "Current password is incorrect." };
  if (bcrypt.compareSync(next, u.passwordHash))
    return { ok: false as const, error: "New password must differ from the current one." };
  db.update(schema.users)
    .set({ passwordHash: hashPassword(next), mustChangePassword: false, failedAttempts: 0, lockedUntil: null })
    .where(eq(schema.users.id, userId))
    .run();
  revokeUserSessions(userId);
  audit(actor ?? { id: userId, email: u.email }, current === null ? "password.reset" : "password.changed", "user", userId);
  return { ok: true as const };
}

export function can(user: SessionUser, p: Permission) {
  return user.permissions.has(p);
}
export { and };
