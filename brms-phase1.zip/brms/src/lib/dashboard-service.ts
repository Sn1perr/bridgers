import { and, count, desc, eq, gte, isNull, ne, sql } from "drizzle-orm";
import { db, schema } from "@/db";
import { can, type SessionUser } from "./auth-core";
import { visibleCondition } from "./records-service";

const { records, categories, users, notifications } = schema;

/** Every figure here is computed from stored rows, scoped to what the signed-in user may see. */
export function getDashboard(user: SessionUser) {
  const vis = visibleCondition(user);
  const total = db.select({ n: count() }).from(records).where(vis).get()!.n;

  const statusRows = db
    .select({ status: records.status, n: count() })
    .from(records)
    .where(vis)
    .groupBy(records.status)
    .all();
  const byStatus = Object.fromEntries(statusRows.map((r) => [r.status, r.n])) as Record<string, number>;

  const since = new Date();
  since.setUTCDate(1);
  since.setUTCMonth(since.getUTCMonth() - 11);
  const trendRows = db
    .select({ month: sql<string>`substr(${records.createdAt},1,7)`, n: count() })
    .from(records)
    .where(and(vis, gte(records.createdAt, since.toISOString().slice(0, 7))))
    .groupBy(sql`substr(${records.createdAt},1,7)`)
    .all();
  const trend: { month: string; label: string; records: number }[] = [];
  for (let i = 0; i < 12; i++) {
    const d = new Date(Date.UTC(since.getUTCFullYear(), since.getUTCMonth() + i, 1));
    const key = d.toISOString().slice(0, 7);
    trend.push({
      month: key,
      label: d.toLocaleString("en-NG", { month: "short", year: "2-digit", timeZone: "UTC" }),
      records: trendRows.find((r) => r.month === key)?.n ?? 0,
    });
  }

  const byCategory = db
    .select({ name: categories.name, n: count() })
    .from(records)
    .innerJoin(categories, eq(categories.id, records.categoryId))
    .where(and(vis, ne(records.status, "Archived")))
    .groupBy(categories.name)
    .orderBy(desc(count()))
    .limit(6)
    .all();

  const awaitingMyApproval = can(user, "records.approve")
    ? db
        .select({ n: count() })
        .from(records)
        .where(and(vis, eq(records.status, "Pending"), ne(records.createdBy, user.id)))
        .get()!.n
    : null;

  const recent = db
    .select({
      id: records.id,
      refNo: records.refNo,
      title: records.title,
      status: records.status,
      updatedAt: records.updatedAt,
      by: users.name,
    })
    .from(records)
    .innerJoin(users, eq(users.id, records.updatedBy))
    .where(vis)
    .orderBy(desc(records.updatedAt), desc(records.id))
    .limit(8)
    .all();

  const urgentOpen = db
    .select({ n: count() })
    .from(records)
    .where(and(vis, eq(records.priority, "Urgent"), sql`${records.status} IN ('Pending','Active')`))
    .get()!.n;

  const people = can(user, "users.manage")
    ? db.select({ n: count() }).from(users).where(eq(users.active, true)).get()!.n
    : null;

  const unread = db
    .select({ n: count() })
    .from(notifications)
    .where(and(eq(notifications.userId, user.id), isNull(notifications.readAt)))
    .get()!.n;

  return { total, byStatus, trend, byCategory, awaitingMyApproval, recent, urgentOpen, people, unread };
}

export function unreadCount(userId: number) {
  return db
    .select({ n: count() })
    .from(notifications)
    .where(and(eq(notifications.userId, userId), isNull(notifications.readAt)))
    .get()!.n;
}
