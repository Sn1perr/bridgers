import { sqliteTable, text, integer, primaryKey, index } from "drizzle-orm/sqlite-core";
import { sql } from "drizzle-orm";

const now = sql`(strftime('%Y-%m-%dT%H:%M:%fZ','now'))`;

export const departments = sqliteTable("departments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull().unique(),
});

export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull(),
  departmentId: integer("department_id").references(() => departments.id),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  mustChangePassword: integer("must_change_password", { mode: "boolean" }).notNull().default(false),
  failedAttempts: integer("failed_attempts").notNull().default(0),
  lockedUntil: text("locked_until"),
  lastLoginAt: text("last_login_at"),
  createdAt: text("created_at").notNull().default(now),
});

export const sessions = sqliteTable("sessions", {
  // SHA-256 hash of the random cookie token; the raw token is never stored.
  id: text("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  createdAt: text("created_at").notNull(),
  lastSeenAt: text("last_seen_at").notNull(),
  ip: text("ip"),
});

export const rolePermissions = sqliteTable(
  "role_permissions",
  {
    role: text("role").notNull(),
    permission: text("permission").notNull(),
  },
  (t) => [primaryKey({ columns: [t.role, t.permission] })],
);

export const categories = sqliteTable("categories", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull().unique(),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: text("created_at").notNull().default(now),
});

export const counters = sqliteTable("counters", {
  key: text("key").primaryKey(),
  value: integer("value").notNull(),
});

export const records = sqliteTable(
  "records",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    refNo: text("ref_no").notNull().unique(),
    title: text("title").notNull(),
    description: text("description").notNull().default(""),
    categoryId: integer("category_id").notNull().references(() => categories.id),
    departmentId: integer("department_id").notNull().references(() => departments.id),
    createdBy: integer("created_by").notNull().references(() => users.id),
    updatedBy: integer("updated_by").notNull().references(() => users.id),
    status: text("status").notNull().default("Pending"), // Active | Pending | Approved | Archived | Rejected
    priority: text("priority").notNull().default("Normal"), // Low | Normal | High | Urgent
    approvedBy: integer("approved_by").references(() => users.id),
    approvedAt: text("approved_at"),
    createdAt: text("created_at").notNull().default(now),
    updatedAt: text("updated_at").notNull().default(now),
    deletedAt: text("deleted_at"), // soft delete
    isDemo: integer("is_demo", { mode: "boolean" }).notNull().default(false),
  },
  (t) => [
    index("records_status_idx").on(t.status),
    index("records_category_idx").on(t.categoryId),
    index("records_department_idx").on(t.departmentId),
    index("records_created_idx").on(t.createdAt),
  ],
);

export const recordNotes = sqliteTable("record_notes", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  recordId: integer("record_id").notNull().references(() => records.id),
  authorId: integer("author_id").notNull().references(() => users.id),
  body: text("body").notNull(),
  createdAt: text("created_at").notNull().default(now),
});

export const attachments = sqliteTable("attachments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  recordId: integer("record_id").notNull().references(() => records.id),
  originalName: text("original_name").notNull(),
  storedName: text("stored_name").notNull(),
  mimeType: text("mime_type").notNull(),
  size: integer("size").notNull(),
  sha256: text("sha256").notNull(),
  uploadedBy: integer("uploaded_by").notNull().references(() => users.id),
  createdAt: text("created_at").notNull().default(now),
  deletedAt: text("deleted_at"),
});

// Append-only. SQLite triggers (see db/index.ts) reject UPDATE and DELETE on this table.
export const auditLogs = sqliteTable(
  "audit_logs",
  {
    id: integer("id").primaryKey({ autoIncrement: true }),
    at: text("at").notNull().default(now),
    userId: integer("user_id"),
    userEmail: text("user_email"),
    action: text("action").notNull(),
    entity: text("entity").notNull(),
    entityId: text("entity_id"),
    detail: text("detail"),
    ip: text("ip"),
  },
  (t) => [index("audit_entity_idx").on(t.entity, t.entityId), index("audit_at_idx").on(t.at)],
);

export const notifications = sqliteTable("notifications", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  body: text("body").notNull().default(""),
  href: text("href"),
  readAt: text("read_at"),
  createdAt: text("created_at").notNull().default(now),
});
