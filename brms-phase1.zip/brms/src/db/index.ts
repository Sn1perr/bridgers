import Database from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import { migrate } from "drizzle-orm/better-sqlite3/migrator";
import fs from "node:fs";
import path from "node:path";
import * as schema from "./schema";
import { DEFAULT_ROLE_PERMISSIONS, ROLE_KEYS } from "@/lib/permissions";

export const DATA_DIR = path.resolve(/*turbopackIgnore: true*/ process.env.BRMS_DATA_DIR ?? "./data");
export const UPLOAD_DIR = path.join(DATA_DIR, "uploads");

type Db = ReturnType<typeof drizzle<typeof schema>>;
const g = globalThis as unknown as { __brmsDb?: Db; __brmsRaw?: Database.Database };

function init(): Db {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  const dbFile = process.env.BRMS_DB_FILE ?? path.join(DATA_DIR, "brms.db");
  const raw = new Database(dbFile);
  raw.pragma("journal_mode = WAL");
  raw.pragma("foreign_keys = ON");
  const db = drizzle(raw, { schema });
  migrate(db, { migrationsFolder: path.resolve(/*turbopackIgnore: true*/ process.cwd(), "drizzle") });

  // The audit trail is permanent: no one, including the application, can edit or erase it.
  raw.exec(`
    CREATE TRIGGER IF NOT EXISTS audit_logs_no_update BEFORE UPDATE ON audit_logs
    BEGIN SELECT RAISE(ABORT, 'audit_logs is append-only'); END;
    CREATE TRIGGER IF NOT EXISTS audit_logs_no_delete BEFORE DELETE ON audit_logs
    BEGIN SELECT RAISE(ABORT, 'audit_logs is append-only'); END;
  `);

  // First run: install default role permissions only if none exist yet.
  const hasPerms = raw.prepare("SELECT 1 FROM role_permissions LIMIT 1").get();
  if (!hasPerms) {
    const ins = raw.prepare("INSERT INTO role_permissions (role, permission) VALUES (?, ?)");
    raw.transaction(() => {
      for (const role of ROLE_KEYS) for (const p of DEFAULT_ROLE_PERMISSIONS[role]) ins.run(role, p);
    })();
  }
  g.__brmsRaw = raw;
  return db;
}

export const db: Db = (g.__brmsDb ??= init());
export const rawDb = () => g.__brmsRaw!;
export { schema };
